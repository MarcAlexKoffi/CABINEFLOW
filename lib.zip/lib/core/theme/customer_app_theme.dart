import 'package:cabine_flow/core/theme/customer_app_colors.dart';
import 'package:flutter/material.dart';

class CustomerAppTheme {
  const CustomerAppTheme._();

  static ThemeData get light {
    const ColorScheme colorScheme = ColorScheme.light(
      primary: CustomerAppColors.primary,
      onPrimary: CustomerAppColors.onPrimary,
      primaryContainer: CustomerAppColors.primaryContainer,
      surface: CustomerAppColors.surface,
      onSurface: CustomerAppColors.onSurface,
      error: CustomerAppColors.error,
      outline: CustomerAppColors.outline,
      outlineVariant: CustomerAppColors.outlineVariant,
    );

    final ThemeData baseTheme = ThemeData(
      useMaterial3: true,
      brightness: Brightness.light,
      colorScheme: colorScheme,
      fontFamily: 'Inter',
    );

    final OutlineInputBorder defaultBorder = OutlineInputBorder(
      borderRadius: BorderRadius.circular(16),
      borderSide: const BorderSide(color: CustomerAppColors.outlineVariant),
    );

    return baseTheme.copyWith(
      scaffoldBackgroundColor: CustomerAppColors.background,
      textTheme: baseTheme.textTheme.copyWith(
        displaySmall: const TextStyle(
          color: CustomerAppColors.onSurface,
          fontSize: 32,
          height: 1.25,
          fontWeight: FontWeight.w800,
          letterSpacing: -0.8,
        ),
        headlineMedium: const TextStyle(
          color: CustomerAppColors.onSurface,
          fontSize: 26,
          height: 1.3,
          fontWeight: FontWeight.w700,
          letterSpacing: -0.4,
        ),
        headlineSmall: const TextStyle(
          color: CustomerAppColors.onSurface,
          fontSize: 22,
          height: 1.35,
          fontWeight: FontWeight.w700,
          letterSpacing: -0.2,
        ),
        bodyLarge: const TextStyle(
          color: CustomerAppColors.onSurfaceVariant,
          fontSize: 16,
          height: 1.6,
          fontWeight: FontWeight.w400,
        ),
        bodyMedium: const TextStyle(
          color: CustomerAppColors.onSurfaceVariant,
          fontSize: 14,
          height: 1.5,
          fontWeight: FontWeight.w400,
        ),
        labelLarge: const TextStyle(
          color: CustomerAppColors.onSurface,
          fontSize: 15,
          height: 1.4,
          fontWeight: FontWeight.w600,
        ),
        labelMedium: const TextStyle(
          color: CustomerAppColors.onSurfaceVariant,
          fontSize: 13,
          height: 1.4,
          fontWeight: FontWeight.w500,
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: CustomerAppColors.surfaceContainerLowest,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 20,
          vertical: 18,
        ),
        hintStyle: const TextStyle(
          color: CustomerAppColors.outline,
          fontSize: 15,
        ),
        prefixIconColor: CustomerAppColors.onSurfaceVariant,
        border: defaultBorder,
        enabledBorder: defaultBorder,
        focusedBorder: defaultBorder.copyWith(
          borderSide: const BorderSide(
            color: CustomerAppColors.primary,
            width: 2,
          ),
        ),
        errorBorder: defaultBorder.copyWith(
          borderSide: const BorderSide(color: CustomerAppColors.error),
        ),
        focusedErrorBorder: defaultBorder.copyWith(
          borderSide: const BorderSide(
            color: CustomerAppColors.error,
            width: 2,
          ),
        ),
        errorStyle: const TextStyle(
          color: CustomerAppColors.error,
          fontSize: 13,
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size.fromHeight(56),
          backgroundColor: CustomerAppColors.primary,
          foregroundColor: CustomerAppColors.onPrimary,
          elevation: 0,
          disabledBackgroundColor: CustomerAppColors.primary.withOpacity(0.4),
          disabledForegroundColor: CustomerAppColors.onPrimary.withOpacity(0.8),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          minimumSize: const Size.fromHeight(56),
          foregroundColor: CustomerAppColors.primary,
          side: const BorderSide(color: CustomerAppColors.primary, width: 1.5),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(16),
          ),
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w700),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: CustomerAppColors.primary,
          textStyle: const TextStyle(fontSize: 15, fontWeight: FontWeight.w600),
        ),
      ),
      progressIndicatorTheme: const ProgressIndicatorThemeData(
        color: CustomerAppColors.primary,
        linearTrackColor: CustomerAppColors.surfaceContainerHighest,
      ),
      snackBarTheme: SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
        backgroundColor: CustomerAppColors.onSurface,
        contentTextStyle: const TextStyle(
          color: CustomerAppColors.surfaceContainerLowest,
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      ),
    );
  }
}
