import 'package:flutter/material.dart';

class CustomerAppColors {
  const CustomerAppColors._();

  static const Color background = Color(0xFFF8FAFC);
  static const Color surface = Color(0xFFF8FAFC);
  static const Color surfaceContainerLowest = Color(0xFFFFFFFF);
  static const Color surfaceContainerLow = Color(0xFFF1F5F9);
  static const Color surfaceContainer = Color(0xFFE2E8F0);
  static const Color surfaceContainerHigh = Color(0xFFCBD5E1);
  static const Color surfaceContainerHighest = Color(0xFF94A3B8);

  static const Color primary = Color(0xFF0033A0); // Bleu profond IzyTel
  static const Color primaryContainer = Color(0xFFE0E7FF); // Bleu très pâle
  static const Color onPrimary = Color(0xFFFFFFFF);

  static const Color onSurface = Color(0xFF0F172A); // Bleu nuit pour textes importants
  static const Color onSurfaceVariant = Color(0xFF475569); // Texte secondaire
  static const Color outline = Color(0xFF94A3B8);
  static const Color outlineVariant = Color(0xFFCBD5E1);

  static const Color error = Color(0xFFDC2626);
  static const Color errorContainer = Color(0xFFFEE2E2);
  static const Color onErrorContainer = Color(0xFF991B1B);

  static const Color success = Color(0xFF16A34A);

  // Couleurs Opérateurs (Accents)
  static const Color orangeCI = Color(0xFFFF6600);
  static const Color mtnCI = Color(0xFFFFCC00);
  static const Color moovCI = Color(0xFF005B9F);
}
