import 'package:cabine_flow/core/theme/customer_app_colors.dart';
import 'package:flutter/material.dart';

class IzyTelCard extends StatelessWidget {
  const IzyTelCard({
    super.key,
    required this.child,
    this.padding = const EdgeInsets.all(20),
    this.onTap,
    this.isSelected = false,
  });

  final Widget child;
  final EdgeInsetsGeometry padding;
  final VoidCallback? onTap;
  final bool isSelected;

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      margin: EdgeInsets.zero,
      color: isSelected ? CustomerAppColors.primaryContainer.withOpacity(0.3) : CustomerAppColors.surfaceContainerLowest,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(16),
        side: BorderSide(
          color: isSelected ? CustomerAppColors.primary : CustomerAppColors.outlineVariant.withOpacity(0.5),
          width: isSelected ? 2 : 1,
        ),
      ),
      clipBehavior: Clip.antiAlias,
      child: InkWell(
        onTap: onTap,
        splashColor: CustomerAppColors.primary.withOpacity(0.1),
        highlightColor: CustomerAppColors.primary.withOpacity(0.05),
        child: Padding(
          padding: padding,
          child: child,
        ),
      ),
    );
  }
}
