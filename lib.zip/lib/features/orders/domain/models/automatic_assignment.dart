import 'package:cabine_flow/features/orders/domain/models/queue_order.dart';

class AutomaticAssignmentQueueItem {
  const AutomaticAssignmentQueueItem({
    required this.orderId,
    required this.orderReference,
    required this.network,
    required this.amount,
    required this.createdAt,
    this.lastRefusedAgentId,
  });

  final String orderId;
  final String orderReference;
  final MobileNetwork network;
  final int amount;
  final DateTime createdAt;
  final String? lastRefusedAgentId;
}

class AutomaticAssignmentAgent {
  const AutomaticAssignmentAgent({
    required this.agentId,
    required this.name,
    required this.isActive,
    required this.isAvailable,
    required this.authorizedNetworks,
    required this.activeNetworks,
    required this.orangeCapacity,
    required this.mtnCapacity,
    required this.moovCapacity,
    required this.dailyTransactionLimit,
    required this.maxTransactionsPerDay,
    required this.activeAssignmentCount,
    required this.orangeReservedAmount,
    required this.mtnReservedAmount,
    required this.moovReservedAmount,
    required this.todayAssignmentCount,
    required this.todayAssignedAmount,
    this.lastAssignedAt,
  });

  final String agentId;
  final String name;
  final bool isActive;
  final bool isAvailable;
  final Set<MobileNetwork> authorizedNetworks;
  final Set<MobileNetwork> activeNetworks;
  final int orangeCapacity;
  final int mtnCapacity;
  final int moovCapacity;
  final int dailyTransactionLimit;
  final int maxTransactionsPerDay;
  final int activeAssignmentCount;
  final int orangeReservedAmount;
  final int mtnReservedAmount;
  final int moovReservedAmount;
  final int todayAssignmentCount;
  final int todayAssignedAmount;
  final DateTime? lastAssignedAt;

  int capacityFor(MobileNetwork network) {
    switch (network) {
      case MobileNetwork.orange:
        return orangeCapacity;
      case MobileNetwork.mtn:
        return mtnCapacity;
      case MobileNetwork.moov:
        return moovCapacity;
    }
  }

  int reservedFor(MobileNetwork network) {
    switch (network) {
      case MobileNetwork.orange:
        return orangeReservedAmount;
      case MobileNetwork.mtn:
        return mtnReservedAmount;
      case MobileNetwork.moov:
        return moovReservedAmount;
    }
  }

  int availableCapacityFor(MobileNetwork network) {
    final int available = capacityFor(network) - reservedFor(network);
    return available < 0 ? 0 : available;
  }

  bool canReceive({required QueueOrder order}) {
    if (!isActive || !isAvailable) return false;
    if (!authorizedNetworks.contains(order.network)) return false;
    if (!activeNetworks.contains(order.network)) return false;
    if (availableCapacityFor(order.network) < order.amount) return false;
    if (order.lastAssignmentRefusedAgentId == agentId) return false;
    if (maxTransactionsPerDay <= 0 || dailyTransactionLimit <= 0) return false;
    if (todayAssignmentCount >= maxTransactionsPerDay) return false;
    if (todayAssignedAmount + order.amount > dailyTransactionLimit) {
      return false;
    }
    return true;
  }
}
