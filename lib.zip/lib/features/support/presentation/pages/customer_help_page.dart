import 'package:cabine_flow/core/theme/customer_app_colors.dart';
import 'package:cabine_flow/shared/widgets/design_system/izy_tel_cards.dart';
import 'package:cabine_flow/shared/widgets/design_system/izy_tel_shell.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class CustomerHelpPage extends StatelessWidget {
  const CustomerHelpPage({
    super.key,
    required this.onBack,
    required this.onOpenRecovery,
  });

  final VoidCallback onBack;
  final VoidCallback onOpenRecovery;

  Future<void> _launchWhatsApp() async {
    const String phoneNumber = '+22500000000'; // Remplacer par le vrai numéro
    final Uri url = Uri.parse('https://wa.me/$phoneNumber');
    if (await canLaunchUrl(url)) {
      await launchUrl(url, mode: LaunchMode.externalApplication);
    }
  }

  @override
  Widget build(BuildContext context) {
    return IzyTelShell(
      title: 'Aide et Contact',
      onBack: onBack,
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text(
              'Comment pouvons-nous vous aider ?',
              style: TextStyle(
                fontSize: 24,
                fontWeight: FontWeight.w800,
                color: CustomerAppColors.onSurface,
              ),
            ),
            const SizedBox(height: 24),
            IzyTelCard(
              onTap: _launchWhatsApp,
              child: const Row(
                children: [
                  Icon(Icons.chat, color: CustomerAppColors.success, size: 32),
                  SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Contacter sur WhatsApp',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: CustomerAppColors.onSurface,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'Notre service client est disponible pour répondre à vos questions.',
                          style: TextStyle(
                            fontSize: 14,
                            color: CustomerAppColors.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Icon(Icons.arrow_forward_ios, color: CustomerAppColors.outline, size: 16),
                ],
              ),
            ),
            const SizedBox(height: 16),
            IzyTelCard(
              onTap: onOpenRecovery,
              child: const Row(
                children: [
                  Icon(Icons.search, color: CustomerAppColors.primary, size: 32),
                  SizedBox(width: 16),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Retrouver une commande',
                          style: TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.bold,
                            color: CustomerAppColors.onSurface,
                          ),
                        ),
                        SizedBox(height: 4),
                        Text(
                          'Même si vous l\'avez effectuée sur un autre appareil.',
                          style: TextStyle(
                            fontSize: 14,
                            color: CustomerAppColors.onSurfaceVariant,
                          ),
                        ),
                      ],
                    ),
                  ),
                  Icon(Icons.arrow_forward_ios, color: CustomerAppColors.outline, size: 16),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
