import 'package:cabine_flow/core/theme/customer_app_colors.dart';
import 'package:cabine_flow/features/customer_order/presentation/widgets/customer_bottom_actions.dart';
import 'package:cabine_flow/features/customer_order/presentation/widgets/customer_progress_indicator.dart';
import 'package:cabine_flow/shared/widgets/design_system/izy_tel_shell.dart';
import 'package:flutter/material.dart';

class CustomerFlowScaffold extends StatelessWidget {
  const CustomerFlowScaffold({
    super.key,
    required this.currentStep,
    required this.totalSteps,
    required this.title,
    required this.content,
    required this.onContinue,
    this.subtitle,
    this.titleTextAlign = TextAlign.start,
    this.onTopBack,
    this.onBottomBack,
    this.footer,
    this.backLabel = 'Retour',
    this.continueLabel = 'Continuer',
    this.isContinueEnabled = true,
    this.isContinueLoading = false,
  });

  final int currentStep;
  final int totalSteps;
  final String title;
  final String? subtitle;
  final TextAlign titleTextAlign;
  final Widget content;
  final VoidCallback onContinue;
  final VoidCallback? onTopBack;
  final VoidCallback? onBottomBack;
  final Widget? footer;
  final String backLabel;
  final String continueLabel;
  final bool isContinueEnabled;
  final bool isContinueLoading;

  @override
  Widget build(BuildContext context) {
    final String? normalizedSubtitle = subtitle?.trim();
    final String? visibleSubtitle =
        normalizedSubtitle == null || normalizedSubtitle.isEmpty
        ? null
        : normalizedSubtitle;

    return IzyTelShell(
      title: 'CabineFlow', // Fallback to app name instead of title so it looks like the design, wait, the design for inner pages often shows "IzyTel". Let's use 'IzyTel'.
      onBack: onTopBack,
      showBackButton: onTopBack != null,
      bottomNavigationBar: CustomerBottomActions(
        onBack: onBottomBack,
        onContinue: onContinue,
        backLabel: backLabel,
        continueLabel: continueLabel,
        isContinueEnabled: isContinueEnabled,
        isLoading: isContinueLoading,
      ),
      child: CustomScrollView(
        slivers: [
          SliverPadding(
            padding: EdgeInsets.fromLTRB(
              20,
              18,
              20,
              footer != null ? 0 : 24,
            ),
            sliver: SliverList(
              delegate: SliverChildListDelegate([
                CustomerProgressIndicator(
                  currentStep: currentStep,
                  totalSteps: totalSteps,
                ),
                const SizedBox(height: 34),
                Text(
                  title,
                  textAlign: titleTextAlign,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                    color: CustomerAppColors.onSurface,
                  ),
                ),
                if (visibleSubtitle != null) ...[
                  const SizedBox(height: 8),
                  Text(
                    visibleSubtitle,
                    textAlign: titleTextAlign,
                    style: const TextStyle(
                      fontSize: 14,
                      color: CustomerAppColors.onSurfaceVariant,
                      height: 1.45,
                    ),
                  ),
                ],
                const SizedBox(height: 26),
                content,
              ]),
            ),
          ),
          if (footer != null)
            SliverFillRemaining(
              hasScrollBody: false,
              fillOverscroll: true,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(
                  20,
                  36,
                  20,
                  24,
                ),
                child: Align(
                  alignment: Alignment.bottomCenter,
                  child: footer!,
                ),
              ),
            ),
        ],
      ),
    );
  }
}


