import 'package:cabine_flow/core/theme/customer_app_colors.dart';
import 'package:cabine_flow/features/customer_order/presentation/view_models/customer_order_view_model.dart';
import 'package:cabine_flow/features/customer_order/presentation/widgets/customer_flow_scaffold.dart';
import 'package:cabine_flow/features/orders/domain/models/queue_order.dart';
import 'package:cabine_flow/shared/widgets/design_system/izy_tel_cards.dart';
import 'package:flutter/material.dart';

class CustomerNetworkPage extends StatelessWidget {
  const CustomerNetworkPage({super.key, required this.viewModel});

  final CustomerOrderViewModel viewModel;

  @override
  Widget build(BuildContext context) {
    final MobileNetwork? selectedNetwork = viewModel.draft.network;

    return CustomerFlowScaffold(
      currentStep: 3,
      totalSteps: CustomerOrderViewModel.totalSteps,
      title: 'Choisissez le réseau',
      subtitle: null,
      onTopBack: viewModel.goBack,
      onBottomBack: viewModel.goBack,
      onContinue: viewModel.continueFromNetwork,
      isContinueEnabled: viewModel.canContinueFromNetwork,
      content: Column(
        children: MobileNetwork.values.map((MobileNetwork network) {
          return Padding(
            padding: EdgeInsets.only(
              bottom: network == MobileNetwork.values.last ? 0 : 16,
            ),
            child: _NetworkOptionCard(
              network: network,
              isSelected: selectedNetwork == network,
              onTap: () {
                viewModel.selectNetwork(network);
              },
            ),
          );
        }).toList(),
      ),
    );
  }
}

class _NetworkOptionCard extends StatelessWidget {
  const _NetworkOptionCard({
    required this.network,
    required this.isSelected,
    required this.onTap,
  });

  final MobileNetwork network;
  final bool isSelected;
  final VoidCallback onTap;

  String get label {
    switch (network) {
      case MobileNetwork.orange:
        return 'Orange';
      case MobileNetwork.mtn:
        return 'MTN';
      case MobileNetwork.moov:
        return 'Moov Africa';
    }
  }



  @override
  Widget build(BuildContext context) {
    final String logoPath = switch (network) {
      MobileNetwork.orange => 'assets/brands/operators/orange.png',
      MobileNetwork.mtn => 'assets/brands/operators/mtn.png',
      MobileNetwork.moov => 'assets/brands/operators/moov.png',
    };

    return Semantics(
      button: true,
      selected: isSelected,
      label: 'Réseau $label',
      child: IzyTelCard(
        isSelected: isSelected,
        onTap: onTap,
        padding: const EdgeInsets.all(20),
        child: Row(
          children: [
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: CustomerAppColors.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(12),
                image: DecorationImage(
                  image: AssetImage(logoPath),
                  fit: BoxFit.cover,
                ),
              ),
            ),
            const SizedBox(width: 18),
            Expanded(
              child: Text(
                label,
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.bold,
                  color: CustomerAppColors.onSurface,
                ),
              ),
            ),
            const SizedBox(width: 12),
            AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              width: 24,
              height: 24,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: isSelected ? CustomerAppColors.primary : Colors.transparent,
                border: Border.all(
                  color: isSelected
                      ? CustomerAppColors.primary
                      : CustomerAppColors.outlineVariant,
                  width: 1.5,
                ),
              ),
              child: isSelected
                  ? const Icon(
                      Icons.check_rounded,
                      size: 16,
                      color: Colors.white,
                    )
                  : null,
            ),
          ],
        ),
      ),
    );
  }
}
