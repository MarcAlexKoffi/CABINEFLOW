import 'package:cabine_flow/core/theme/customer_app_colors.dart';
import 'package:cabine_flow/shared/widgets/design_system/izy_tel_buttons.dart';
import 'package:cabine_flow/shared/widgets/design_system/izy_tel_cards.dart';
import 'package:cabine_flow/shared/widgets/design_system/izy_tel_shell.dart';
import 'package:flutter/material.dart';

class CustomerHomePage extends StatelessWidget {
  const CustomerHomePage({
    super.key,
    required this.onStartOrder,
    required this.onOpenHistory,
    required this.onOpenHelp,
  });

  final VoidCallback onStartOrder;
  final VoidCallback onOpenHistory;
  final VoidCallback onOpenHelp;

  @override
  Widget build(BuildContext context) {
    return IzyTelShell(
      title: 'IzyTel',
      showBackButton: false,
      actions: [
        TextButton(
          onPressed: onStartOrder,
          child: const Text('Commander', style: TextStyle(fontWeight: FontWeight.w700)),
        ),
      ],
      bottomNavigationBar: _buildBottomNav(),
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            _buildHero(),
            const SizedBox(height: 32),
            _buildQuickActions(),
            const SizedBox(height: 32),
            _buildReassurance(),
          ],
        ),
      ),
    );
  }

  Widget _buildHero() {
    return Column(
      children: [
        Container(
          height: 200,
          decoration: BoxDecoration(
            color: CustomerAppColors.surfaceContainerHigh,
            borderRadius: BorderRadius.circular(24),
            image: const DecorationImage(
              image: AssetImage('assets/images/app_logo.png'), // Placeholder or hero image
              fit: BoxFit.cover,
            ),
          ),
        ),
        const SizedBox(height: 24),
        const Text(
          'Vos forfaits et unités, simplement.',
          style: TextStyle(
            fontSize: 28,
            fontWeight: FontWeight.w800,
            color: CustomerAppColors.primary,
            height: 1.2,
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 12),
        const Text(
          'Internet, appels et transfert d\'unités\nOrange, MTN et Moov.',
          style: TextStyle(
            fontSize: 16,
            color: CustomerAppColors.onSurfaceVariant,
            height: 1.5,
          ),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 32),
        IzyTelPrimaryButton(
          text: 'Faire une commande',
          onPressed: onStartOrder,
        ),
        const SizedBox(height: 12),
        IzyTelSecondaryButton(
          text: 'Voir les offres',
          onPressed: () {}, // Not strictly required yet, or scroll to offers
        ),
      ],
    );
  }

  Widget _buildQuickActions() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Que voulez-vous faire ?',
          style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 16),
        Row(
          children: [
            Expanded(child: _buildActionCard('Transfert d\'unités', Icons.phone_android)),
            const SizedBox(width: 12),
            Expanded(child: _buildActionCard('Internet', Icons.wifi)),
            const SizedBox(width: 12),
            Expanded(child: _buildActionCard('Appels', Icons.phone)),
          ],
        )
      ],
    );
  }

  Widget _buildActionCard(String title, IconData icon) {
    return IzyTelCard(
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 8),
      onTap: onStartOrder,
      child: Column(
        children: [
          Icon(icon, color: CustomerAppColors.primary, size: 28),
          const SizedBox(height: 8),
          Text(
            title,
            textAlign: TextAlign.center,
            style: const TextStyle(fontSize: 12, fontWeight: FontWeight.bold),
          ),
        ],
      ),
    );
  }

  Widget _buildReassurance() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      children: [
        _buildTrustItem(Icons.no_accounts, 'Aucun compte'),
        _buildTrustItem(Icons.lock, 'Sécurisé'),
        _buildTrustItem(Icons.local_shipping, 'Suivi'),
      ],
    );
  }

  Widget _buildTrustItem(IconData icon, String text) {
    return Column(
      children: [
        Icon(icon, color: CustomerAppColors.primary, size: 24),
        const SizedBox(height: 4),
        Text(text, style: const TextStyle(fontSize: 12, color: CustomerAppColors.onSurfaceVariant)),
      ],
    );
  }

  Widget _buildBottomNav() {
    return Container(
      decoration: BoxDecoration(
        color: CustomerAppColors.surfaceContainerLowest,
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, -5),
          ),
        ],
      ),
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildNavItem(Icons.home, 'Accueil', true, () {}),
              _buildNavItem(Icons.card_giftcard, 'Forfaits', false, onStartOrder),
              _buildNavItem(Icons.history, 'Historique', false, onOpenHistory),
              _buildNavItem(Icons.help_outline, 'Aide', false, onOpenHelp),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildNavItem(IconData icon, String label, bool isActive, VoidCallback onTap) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        decoration: BoxDecoration(
          color: isActive ? CustomerAppColors.success.withOpacity(0.2) : Colors.transparent,
          borderRadius: BorderRadius.circular(24),
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              icon,
              color: isActive ? CustomerAppColors.success : CustomerAppColors.onSurfaceVariant,
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                fontSize: 11,
                fontWeight: isActive ? FontWeight.bold : FontWeight.normal,
                color: isActive ? CustomerAppColors.success : CustomerAppColors.onSurfaceVariant,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
