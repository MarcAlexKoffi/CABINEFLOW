import 'package:cabine_flow/features/customer_order/domain/models/customer_offer.dart';
import 'package:cabine_flow/features/customer_order/domain/models/customer_service.dart';
import 'package:cabine_flow/features/customer_order/domain/repositories/customer_offer_repository.dart';
import 'package:cabine_flow/features/orders/domain/models/queue_order.dart';

class FakeCustomerOfferRepository implements CustomerOfferRepository {
  const FakeCustomerOfferRepository();

  @override
  Stream<List<CustomerOffer>> watchOffers({
    required CustomerService service,
    required MobileNetwork network,
  }) async* {
    yield await fetchOffers(service: service, network: network);
  }

  @override
  Stream<List<CustomerOffer>> watchAllOffers() async* {
    final List<List<CustomerOffer>> groups = await Future.wait(
      <Future<List<CustomerOffer>>>[
        for (final MobileNetwork network in MobileNetwork.values)
          ...<Future<List<CustomerOffer>>>[
            fetchOffers(
              service: CustomerService.internetSubscription,
              network: network,
            ),
            fetchOffers(service: CustomerService.calls, network: network),
          ],
      ],
    );
    yield List<CustomerOffer>.unmodifiable(groups.expand((items) => items));
  }

  static const List<CustomerOffer> _offers = <CustomerOffer>[
    CustomerOffer(
      id: 'orange-internet-500',
      network: MobileNetwork.orange,
      type: CustomerOfferType.internet,
      title: '1,5 Go',
      catalogLabel: 'Internet Orange 1,5 Go - 3 jours',
      amount: 500,
      details: <String>['Validité : 3 jours'],
    ),
    CustomerOffer(
      id: 'orange-internet-1000',
      network: MobileNetwork.orange,
      type: CustomerOfferType.internet,
      title: '4 Go',
      catalogLabel: 'Internet Orange 4 Go - 7 jours',
      amount: 1000,
      details: <String>['Validité : 7 jours'],
    ),
    CustomerOffer(
      id: 'orange-internet-2500',
      network: MobileNetwork.orange,
      type: CustomerOfferType.internet,
      title: '10 Go',
      catalogLabel: 'Internet Orange 10 Go - 7 jours',
      amount: 2500,
      details: <String>['Validité : 7 jours'],
    ),
    CustomerOffer(
      id: 'orange-internet-5000',
      network: MobileNetwork.orange,
      type: CustomerOfferType.internet,
      title: '7,2 Go',
      catalogLabel: 'Internet Orange 7,2 Go - 30 jours',
      amount: 5000,
      details: <String>['Validité : 30 jours'],
    ),
    CustomerOffer(
      id: 'orange-internet-10000',
      network: MobileNetwork.orange,
      type: CustomerOfferType.internet,
      title: '15 Go',
      catalogLabel: 'Internet Orange 15 Go - 30 jours',
      amount: 10000,
      details: <String>['Validité : 30 jours'],
    ),
    CustomerOffer(
      id: 'orange-internet-20000',
      network: MobileNetwork.orange,
      type: CustomerOfferType.internet,
      title: '36 Go',
      catalogLabel: 'Internet Orange 36 Go - 30 jours',
      amount: 20000,
      details: <String>['Validité : 30 jours'],
    ),
    CustomerOffer(
      id: 'mtn-internet-500',
      network: MobileNetwork.mtn,
      type: CustomerOfferType.internet,
      title: '1,5 Go',
      catalogLabel: 'Internet MTN 1,5 Go - 3 jours',
      amount: 500,
      details: <String>['Validité : 3 jours'],
    ),
    CustomerOffer(
      id: 'mtn-internet-1000',
      network: MobileNetwork.mtn,
      type: CustomerOfferType.internet,
      title: '4 Go',
      catalogLabel: 'Internet MTN 4 Go - 7 jours',
      amount: 1000,
      details: <String>['Validité : 7 jours'],
    ),
    CustomerOffer(
      id: 'mtn-internet-1500',
      network: MobileNetwork.mtn,
      type: CustomerOfferType.internet,
      title: '6 Go',
      catalogLabel: 'Internet MTN 6 Go - 7 jours',
      amount: 1500,
      details: <String>['Validité : 7 jours'],
    ),
    CustomerOffer(
      id: 'mtn-internet-2500',
      network: MobileNetwork.mtn,
      type: CustomerOfferType.internet,
      title: '10 Go',
      catalogLabel: 'Internet MTN 10 Go - 10 jours',
      amount: 2500,
      details: <String>['Validité : 10 jours'],
    ),
    CustomerOffer(
      id: 'mtn-internet-10000',
      network: MobileNetwork.mtn,
      type: CustomerOfferType.internet,
      title: '40 Go',
      catalogLabel: 'Internet MTN 40 Go - 15 jours',
      amount: 10000,
      details: <String>['Validité : 15 jours'],
    ),
    CustomerOffer(
      id: 'mtn-internet-20000',
      network: MobileNetwork.mtn,
      type: CustomerOfferType.internet,
      title: '45 Go',
      catalogLabel: 'Internet MTN 45 Go - 30 jours',
      amount: 20000,
      details: <String>['Validité : 30 jours'],
    ),
    CustomerOffer(
      id: 'moov-internet-200',
      network: MobileNetwork.moov,
      type: CustomerOfferType.internet,
      title: '650 Mo',
      catalogLabel: 'Internet Moov 650 Mo',
      amount: 200,
      details: <String>['Validité à confirmer'],
      badgeLabel: 'Validité à confirmer',
    ),
    CustomerOffer(
      id: 'moov-internet-500',
      network: MobileNetwork.moov,
      type: CustomerOfferType.internet,
      title: '1,5 Go',
      catalogLabel: 'Internet Moov 1,5 Go - 7 jours',
      amount: 500,
      details: <String>['Validité : 7 jours'],
    ),
    CustomerOffer(
      id: 'moov-internet-1000',
      network: MobileNetwork.moov,
      type: CustomerOfferType.internet,
      title: '4 Go',
      catalogLabel: 'Internet Moov 4 Go - 7 jours',
      amount: 1000,
      details: <String>['Validité : 7 jours'],
    ),
    CustomerOffer(
      id: 'moov-internet-1500',
      network: MobileNetwork.moov,
      type: CustomerOfferType.internet,
      title: '6 Go',
      catalogLabel: 'Internet Moov 6 Go - 10 jours',
      amount: 1500,
      details: <String>['Validité : 10 jours'],
    ),
    CustomerOffer(
      id: 'moov-internet-2500',
      network: MobileNetwork.moov,
      type: CustomerOfferType.internet,
      title: '10 Go',
      catalogLabel: 'Internet Moov 10 Go - 30 jours',
      amount: 2500,
      details: <String>['Validité : 30 jours'],
    ),
    CustomerOffer(
      id: 'orange-calls-500',
      network: MobileNetwork.orange,
      type: CustomerOfferType.calls,
      title: 'Pass Mix 500',
      catalogLabel: 'Orange Pass Mix 500',
      amount: 500,
      details: <String>[
        '50 min tous réseaux',
        '250 Mo d’Internet',
        'Validité : 7 jours',
      ],
      badgeLabel: 'Mixte',
    ),
    CustomerOffer(
      id: 'orange-calls-1000',
      network: MobileNetwork.orange,
      type: CustomerOfferType.calls,
      title: 'Pass Mix 1 000',
      catalogLabel: 'Orange Pass Mix 1 000',
      amount: 1000,
      details: <String>[
        '100 min tous réseaux',
        '1 Go d’Internet',
        'Validité : 7 jours',
      ],
      badgeLabel: 'Mixte',
    ),
    CustomerOffer(
      id: 'orange-calls-1500',
      network: MobileNetwork.orange,
      type: CustomerOfferType.calls,
      title: 'Pass Mix 1 500',
      catalogLabel: 'Orange Pass Mix 1 500',
      amount: 1500,
      details: <String>[
        '200 min tous réseaux',
        '1,5 Go d’Internet',
        'Validité : 7 jours',
      ],
      badgeLabel: 'Mixte',
    ),
    CustomerOffer(
      id: 'orange-calls-3000',
      network: MobileNetwork.orange,
      type: CustomerOfferType.calls,
      title: 'Pass Mix 3 000',
      catalogLabel: 'Orange Pass Mix 3 000',
      amount: 3000,
      details: <String>[
        '250 min tous réseaux',
        '2,5 Go d’Internet',
        'Validité : 30 jours',
      ],
      badgeLabel: 'Mixte',
    ),
    CustomerOffer(
      id: 'orange-calls-5000',
      network: MobileNetwork.orange,
      type: CustomerOfferType.calls,
      title: 'Pass Mix 5 000',
      catalogLabel: 'Orange Pass Mix 5 000',
      amount: 5000,
      details: <String>[
        '400 min tous réseaux',
        '5 Go d’Internet',
        'Validité : 30 jours',
      ],
      badgeLabel: 'Mixte',
    ),
    CustomerOffer(
      id: 'orange-calls-10000',
      network: MobileNetwork.orange,
      type: CustomerOfferType.calls,
      title: 'Pass Mix 10 000',
      catalogLabel: 'Orange Pass Mix Premium 10 000',
      amount: 10000,
      details: <String>[
        'Appels illimités vers Orange',
        '3 600 min vers les autres réseaux',
        '15 Go d’Internet',
        '500 SMS',
        'Validité : 30 jours',
      ],
      badgeLabel: 'Gros consommateur',
    ),
    CustomerOffer(
      id: 'mtn-calls-500',
      network: MobileNetwork.mtn,
      type: CustomerOfferType.calls,
      title: 'Free Plus 500',
      catalogLabel: 'MTN Free Plus 500',
      amount: 500,
      details: <String>[
        '55 min tous réseaux',
        '300 Mo d’Internet',
        '100 SMS',
        'Validité : 5 jours',
      ],
      badgeLabel: 'Mixte',
    ),
    CustomerOffer(
      id: 'mtn-calls-1000',
      network: MobileNetwork.mtn,
      type: CustomerOfferType.calls,
      title: 'Free Plus 1 000',
      catalogLabel: 'MTN Free Plus 1 000',
      amount: 1000,
      details: <String>[
        '100 min tous réseaux',
        '1 Go d’Internet',
        '100 SMS',
        'Validité : 10 jours',
      ],
      badgeLabel: 'Mixte',
    ),
    CustomerOffer(
      id: 'mtn-calls-1500',
      network: MobileNetwork.mtn,
      type: CustomerOfferType.calls,
      title: 'Free Plus 1 500',
      catalogLabel: 'MTN Free Plus 1 500',
      amount: 1500,
      details: <String>[
        '200 min tous réseaux',
        '1,5 Go d’Internet',
        '150 SMS',
        'Validité : 15 jours',
      ],
      badgeLabel: 'Mixte',
    ),
    CustomerOffer(
      id: 'mtn-calls-2500',
      network: MobileNetwork.mtn,
      type: CustomerOfferType.calls,
      title: 'Free Plus 2 500',
      catalogLabel: 'MTN Free Plus 2 500',
      amount: 2500,
      details: <String>[
        '250 min tous réseaux',
        '2,5 Go d’Internet',
        '250 SMS',
        'Validité : 30 jours',
      ],
      badgeLabel: 'Mixte',
    ),
    CustomerOffer(
      id: 'mtn-calls-5000',
      network: MobileNetwork.mtn,
      type: CustomerOfferType.calls,
      title: 'Free Plus 5 000',
      catalogLabel: 'MTN Free Plus 5 000',
      amount: 5000,
      details: <String>[
        '500 min tous réseaux',
        '5 Go d’Internet',
        '500 SMS',
        'Validité : 30 jours',
      ],
      badgeLabel: 'Mixte',
    ),
    CustomerOffer(
      id: 'mtn-calls-10000',
      network: MobileNetwork.mtn,
      type: CustomerOfferType.calls,
      title: 'Free Plus 10 000',
      catalogLabel: 'MTN Free Plus 10 000',
      amount: 10000,
      details: <String>[
        '830 min tous réseaux',
        '10 Go d’Internet',
        '500 SMS',
        'Validité : 30 jours',
      ],
      badgeLabel: 'Mixte',
    ),
    CustomerOffer(
      id: 'moov-calls-500',
      network: MobileNetwork.moov,
      type: CustomerOfferType.calls,
      title: 'Moov Folie 70 min',
      catalogLabel: 'Moov Folie Appels 70 min - 5 jours',
      amount: 500,
      details: <String>['70 min tous réseaux', 'Validité : 5 jours'],
      badgeLabel: 'Appels seuls',
    ),
    CustomerOffer(
      id: 'moov-calls-1000',
      network: MobileNetwork.moov,
      type: CustomerOfferType.calls,
      title: 'Moov Folie 140 min',
      catalogLabel: 'Moov Folie Appels 140 min - 15 jours',
      amount: 1000,
      details: <String>['140 min tous réseaux', 'Validité : 15 jours'],
      badgeLabel: 'Appels seuls',
    ),
    CustomerOffer(
      id: 'moov-calls-1500',
      network: MobileNetwork.moov,
      type: CustomerOfferType.calls,
      title: 'Moov Folie 210 min',
      catalogLabel: 'Moov Folie Appels 210 min - 21 jours',
      amount: 1500,
      details: <String>['210 min tous réseaux', 'Validité : 21 jours'],
      badgeLabel: 'Appels seuls',
    ),
    CustomerOffer(
      id: 'moov-calls-2500',
      network: MobileNetwork.moov,
      type: CustomerOfferType.calls,
      title: 'Moov Folie 350 min',
      catalogLabel: 'Moov Folie Appels 350 min - 30 jours',
      amount: 2500,
      details: <String>['350 min tous réseaux', 'Validité : 30 jours'],
      badgeLabel: 'Appels seuls',
    ),
    CustomerOffer(
      id: 'moov-calls-5000',
      network: MobileNetwork.moov,
      type: CustomerOfferType.calls,
      title: 'Moov Folie 700 min',
      catalogLabel: 'Moov Folie Appels 700 min - 30 jours',
      amount: 5000,
      details: <String>['700 min tous réseaux', 'Validité : 30 jours'],
      badgeLabel: 'Appels seuls',
    ),
  ];

  @override
  Future<List<CustomerOffer>> fetchOffers({
    required CustomerService service,
    required MobileNetwork network,
  }) async {
    await Future<void>.delayed(const Duration(milliseconds: 250));

    final CustomerOfferType? offerType = switch (service) {
      CustomerService.internetSubscription => CustomerOfferType.internet,
      CustomerService.calls => CustomerOfferType.calls,
      CustomerService.unitTransfer => null,
    };

    if (offerType == null) {
      return const <CustomerOffer>[];
    }

    return List<CustomerOffer>.unmodifiable(
      _offers.where((CustomerOffer offer) {
        return offer.network == network && offer.type == offerType;
      }),
    );
  }
}
