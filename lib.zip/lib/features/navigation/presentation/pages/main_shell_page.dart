import 'dart:async';

import 'package:cabine_flow/app/app_routes.dart';
import 'package:cabine_flow/core/notifications/firebase_messaging_bootstrap.dart';
import 'package:cabine_flow/core/notifications/izytel_notification_device_registry.dart';
import 'package:cabine_flow/core/notifications/izytel_notification_payload.dart';
import 'package:cabine_flow/core/services/session_preferences.dart';
import 'package:cabine_flow/core/theme/izytel_colors.dart';
import 'package:cabine_flow/core/theme/izytel_design_tokens.dart';
import 'package:cabine_flow/core/supabase/supabase_bootstrap.dart';
import 'package:cabine_flow/features/finances/data/services/phase5_consolidated_synchronizer.dart';
import 'package:cabine_flow/features/agents/domain/models/agent_models.dart';
import 'package:cabine_flow/features/agents/domain/repositories/agent_repository.dart';
import 'package:cabine_flow/features/agents/presentation/pages/agent_activity_page.dart';
import 'package:cabine_flow/features/agents/presentation/pages/agent_activity_v2_dashboard_page.dart';
import 'package:cabine_flow/features/agents/presentation/pages/agent_home_page.dart';
import 'package:cabine_flow/features/agents/presentation/pages/agent_issue_center_page.dart';
import 'package:cabine_flow/features/agents/presentation/pages/agent_issues_page.dart';
import 'package:cabine_flow/features/agents/presentation/pages/agent_management_page.dart';
import 'package:cabine_flow/features/auth/domain/models/app_user.dart';
import 'package:cabine_flow/features/auth/domain/permissions/user_permissions.dart';
import 'package:cabine_flow/features/auth/domain/repositories/auth_repository.dart';
import 'package:cabine_flow/features/commissions/domain/repositories/commission_repository.dart';
import 'package:cabine_flow/features/commissions/presentation/pages/agent_commissions_page.dart';
import 'package:cabine_flow/features/dashboard/domain/repositories/dashboard_repository.dart';
import 'package:cabine_flow/features/dashboard/presentation/pages/dashboard_page.dart';
import 'package:cabine_flow/features/dashboard/presentation/widgets/dashboard_widgets.dart';
import 'package:cabine_flow/features/finances/presentation/pages/finances_page.dart';
import 'package:cabine_flow/features/more/presentation/pages/more_page.dart';
import 'package:cabine_flow/features/offers/domain/repositories/admin_offer_repository.dart';
import 'package:cabine_flow/features/orders/domain/models/automatic_assignment.dart';
import 'package:cabine_flow/features/orders/domain/models/queue_order.dart';
import 'package:cabine_flow/features/orders/presentation/pages/agent_history_page.dart';
import 'package:cabine_flow/features/orders/presentation/pages/orders_page.dart';
import 'package:cabine_flow/features/orders/presentation/navigation/staff_order_navigation.dart';
import 'package:cabine_flow/features/orders/presentation/pages/agent_orders_page.dart';
import 'package:cabine_flow/features/payments/presentation/pages/payments_page.dart';
import 'package:cabine_flow/features/payments/domain/repositories/payment_link_repository.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:material_symbols_icons/symbols.dart';
import 'package:cabine_flow/features/orders/domain/repositories/order_history_repository.dart';
import 'package:cabine_flow/features/orders/domain/repositories/orders_repository.dart';
import 'package:cabine_flow/features/orders/domain/repositories/offer_catalog_repository.dart';
import 'package:cabine_flow/shared/widgets/izytel/izytel_feedback.dart';

class MainShellPage extends StatefulWidget {
  const MainShellPage({
    super.key,
    required this.user,
    required this.authRepository,
    required this.dashboardRepository,
    required this.ordersRepository,
    required this.offerCatalogRepository,
    required this.adminOfferRepository,
    required this.paymentLinkRepository,
    required this.agentRepository,
    required this.commissionRepository,
  });

  final AppUser user;
  final AuthRepository authRepository;
  final DashboardRepository dashboardRepository;
  final OrdersRepository ordersRepository;
  final OfferCatalogRepository offerCatalogRepository;
  final AdminOfferRepository adminOfferRepository;
  final PaymentLinkRepository paymentLinkRepository;
  final AgentRepository agentRepository;
  final CommissionRepository commissionRepository;

  @override
  State<MainShellPage> createState() {
    return _MainShellPageState();
  }
}

class _MainShellPageState extends State<MainShellPage> {
  int _selectedIndex = 0;
  StreamSubscription<List<AgentDirectoryEntry>>? _staffAgentsSubscription;
  StreamSubscription<List<AutomaticAssignmentQueueItem>>?
  _staffQueueSubscription;
  Timer? _automaticAssignmentDebounce;
  bool _automaticAssignmentSyncRunning = false;
  bool _automaticAssignmentSyncPending = false;
  bool _managerSupabaseStaffDenied = false;
  bool _managerSupabaseWarningShown = false;
  bool _isLoggingOut = false;
  DateTime? _lastBackPressAt;
  bool _handlingSystemBack = false;
  late final List<NavigatorObserver> _tabNavigatorObservers;
  StreamSubscription<IzyTelNotificationPayload>? _notificationOpenedSubscription;
  StreamSubscription<IzyTelNotificationPayload>? _notificationForegroundSubscription;

  final List<GlobalKey<NavigatorState>> _tabNavigatorKeys =
      List<GlobalKey<NavigatorState>>.generate(
        5,
        (int index) =>
            GlobalKey<NavigatorState>(debugLabel: 'admin-tab-$index'),
      );

  @override
  void initState() {
    super.initState();
    _tabNavigatorObservers = List<NavigatorObserver>.generate(
      _tabNavigatorKeys.length,
      (_) => _IzyTelTabNavigationObserver(_disarmExit),
    );
    unawaited(IzyTelNotificationDeviceRegistry.start(user: widget.user));
    if (widget.user.role != UserRole.agent) {
      _wireStaffNotifications();
      _startAutomaticAssignmentWatchers();
      _scheduleAutomaticAssignmentSync(immediate: true);
      if (SupabaseBootstrap.isInitialized &&
          widget.user.role == UserRole.administrator) {
        unawaited(_synchronizePhase5ConsolidatedBackfill());
      }
    }
  }

  void _wireStaffNotifications() {
    _notificationForegroundSubscription =
        FirebaseMessagingBootstrap.foregroundPayloads.listen(
      (IzyTelNotificationPayload payload) {
        if (!mounted) return;
        IzyTelFeedback.show(context, payload.displayMessage);
      },
      onError: (Object error) {
        debugPrint('[FCM][staff-foreground-stream] $error');
      },
    );
    _notificationOpenedSubscription =
        FirebaseMessagingBootstrap.openedPayloads.listen(
      (IzyTelNotificationPayload payload) {
        unawaited(_handleStaffNotificationOpen(payload));
      },
      onError: (Object error) {
        debugPrint('[FCM][staff-opened-stream] $error');
      },
    );
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final IzyTelNotificationPayload? pending =
          FirebaseMessagingBootstrap.takePendingOpenedPayload();
      if (pending != null) unawaited(_handleStaffNotificationOpen(pending));
    });
  }

  Future<void> _handleStaffNotificationOpen(
    IzyTelNotificationPayload payload,
  ) async {
    if (!mounted) return;

    if (payload.targetsOrder ||
        payload.type == 'order_assigned' ||
        payload.type == 'order_reassigned' ||
        payload.type == 'order_manual_required') {
      final String? orderId = payload.orderId?.trim();
      final OrdersRepository rawRepository = widget.ordersRepository;
      if (orderId == null ||
          orderId.isEmpty ||
          rawRepository is! OrderHistoryRepository) {
        _openOrdersTab();
        return;
      }
      try {
        final OrderHistoryRepository history =
            rawRepository as OrderHistoryRepository;
        final QueueOrder order =
            await history.fetchOrderById(orderId: orderId);
        if (!mounted) return;
        await _openSpecificOrder(order);
      } catch (_) {
        if (mounted) _openOrdersTab();
      }
      return;
    }

    if (payload.type == 'agent_issue_new') {
      _openMoreTab();
      await Future<void>.delayed(Duration.zero);
      if (!mounted) return;
      final NavigatorState? moreNavigator = _tabNavigatorKeys[4].currentState;
      moreNavigator?.popUntil((Route<dynamic> route) => route.isFirst);
      moreNavigator?.push<void>(
        MaterialPageRoute<void>(
          builder: (_) => AgentIssueCenterPage(
            user: widget.user,
            repository: widget.agentRepository,
          ),
        ),
      );
      return;
    }

    if (payload.type.startsWith('payment_')) {
      _openPaymentsTab();
    }
  }

  Future<void> _synchronizePhase5ConsolidatedBackfill() async {
    try {
      await Future<void>.delayed(const Duration(milliseconds: 800));
      await Phase5ConsolidatedSynchronizer().synchronize();
    } catch (error, stackTrace) {
      debugPrint('[Phase5][ConsolidatedSync] $error');
      debugPrintStack(stackTrace: stackTrace);
    }
  }

  void _startAutomaticAssignmentWatchers() {
    _staffAgentsSubscription = widget.agentRepository.watchAgents().listen(
      (_) => _scheduleAutomaticAssignmentSync(),
      onError: (Object error) {
        debugPrint('[AutoAssignment][staff-watch-agents] $error');
      },
    );
    _staffQueueSubscription = widget.ordersRepository
        .watchAutomaticAssignmentQueue()
        .listen(
          (_) => _scheduleAutomaticAssignmentSync(),
          onError: (Object error) {
            debugPrint('[AutoAssignment][staff-watch-queue] $error');
          },
        );
  }

  void _scheduleAutomaticAssignmentSync({bool immediate = false}) {
    if (_managerSupabaseStaffDenied) return;
    if (WidgetsBinding.instance.runtimeType.toString().contains('Test')) {
      if (immediate) {
        unawaited(_synchronizeAutomaticAssignmentBacklog());
      }
      return;
    }
    _automaticAssignmentDebounce?.cancel();
    if (immediate) {
      unawaited(_synchronizeAutomaticAssignmentBacklog());
      return;
    }
    _automaticAssignmentDebounce = Timer(
      const Duration(milliseconds: 300),
      () => unawaited(_synchronizeAutomaticAssignmentBacklog()),
    );
  }

  Future<void> _synchronizeAutomaticAssignmentBacklog() async {
    if (_automaticAssignmentSyncRunning) {
      _automaticAssignmentSyncPending = true;
      return;
    }

    _automaticAssignmentSyncRunning = true;
    try {
      await widget.ordersRepository.synchronizeAutomaticAssignmentBacklog();
    } catch (error, stackTrace) {
      final String raw = error.toString();
      if (widget.user.isManager && raw.contains('STAFF_REQUIRED')) {
        _managerSupabaseStaffDenied = true;
        debugPrint(
          '[Manager][Supabase] accès staff absent : synchronisation Phase 4 suspendue jusqu’à la prochaine connexion.',
        );
        if (mounted && !_managerSupabaseWarningShown) {
          _managerSupabaseWarningShown = true;
          WidgetsBinding.instance.addPostFrameCallback((_) {
            if (!mounted) return;
            IzyTelFeedback.show(
              context,
              'Accès Supabase Manager incomplet. Enregistre ce compte dans izytel_staff_access puis reconnecte-toi.',
              tone: IzyTelFeedbackTone.warning,
            );
          });
        }
      } else {
        debugPrint('[AutoAssignment][backlog] $error');
        debugPrint('[AutoAssignment][backlog] stack:\n$stackTrace');
      }
    } finally {
      _automaticAssignmentSyncRunning = false;
      if (_automaticAssignmentSyncPending) {
        _automaticAssignmentSyncPending = false;
        _scheduleAutomaticAssignmentSync();
      }
    }
  }

  void _handlePaymentConfirmed() {
    _scheduleAutomaticAssignmentSync(immediate: true);
  }

  @override
  void dispose() {
    _automaticAssignmentDebounce?.cancel();
    _staffAgentsSubscription?.cancel();
    _staffQueueSubscription?.cancel();
    _notificationOpenedSubscription?.cancel();
    _notificationForegroundSubscription?.cancel();
    super.dispose();
  }

  void _openOrdersTab() {
    _selectDestination(1);
  }

  Future<void> _openSpecificOrder(QueueOrder order) async {
    final OrdersRepository rawRepository = widget.ordersRepository;
    if (rawRepository is! OrderHistoryRepository) {
      _openOrdersTab();
      return;
    }
    final OrderHistoryRepository repository =
        rawRepository as OrderHistoryRepository;

    QueueOrder latest = order;
    try {
      latest = await repository.fetchOrderById(orderId: order.id);
    } catch (_) {
      // Le détail peut tout de même s'ouvrir avec le snapshot déjà affiché.
    }
    if (!mounted) return;

    _selectDestination(1);
    await Future<void>.delayed(Duration.zero);
    if (!mounted) return;

    final NavigatorState? navigator = _tabNavigatorKeys[1].currentState;
    if (navigator == null) return;

    navigator.popUntil((Route<dynamic> route) => route.isFirst);
    await navigator.push<void>(
      StaffOrderNavigation.orderDetailRoute(
        user: widget.user,
        repository: repository,
        order: latest,
      ),
    );
  }

  void _openPaymentsTab() {
    _selectDestination(2);
  }

  void _openMoreTab() {
    _selectDestination(4);
  }

  Future<void> _logoutAdmin() async {
    if (_isLoggingOut) return;

    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: const Text('Se déconnecter ?'),
          content: const Text(
            'Tu devras te reconnecter pour accéder de nouveau à IzyTel.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Annuler'),
            ),
            FilledButton.icon(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              icon: const Icon(Symbols.logout_rounded),
              label: const Text('Se déconnecter'),
            ),
          ],
        );
      },
    );

    if (confirmed != true || !mounted) return;

    setState(() {
      _isLoggingOut = true;
    });

    try {
      await IzyTelNotificationDeviceRegistry.deactivateCurrentDevice();
      await widget.authRepository.logout();
      await SessionPreferences.clear();
      if (!mounted) return;
      Navigator.of(context, rootNavigator: true).pushNamedAndRemoveUntil(
        AppRoutes.login,
        (Route<dynamic> route) => false,
      );
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _isLoggingOut = false;
      });
      IzyTelFeedback.error(
        context,
        'Impossible de se déconnecter pour le moment.',
      );
    }
  }

  void _disarmExit() {
    _lastBackPressAt = null;
  }

  void _popTabToRoot(int index) {
    _tabNavigatorKeys[index].currentState?.popUntil(
      (Route<dynamic> route) => route.isFirst,
    );
  }

  Future<void> _handleSystemBack() async {
    if (_handlingSystemBack) return;
    _handlingSystemBack = true;
    try {
      final NavigatorState? currentNavigator =
          _tabNavigatorKeys[_selectedIndex].currentState;

      if (currentNavigator != null && await currentNavigator.maybePop()) {
        _disarmExit();
        return;
      }

      if (_selectedIndex != 0) {
        _disarmExit();
        _popTabToRoot(0);
        if (mounted) setState(() => _selectedIndex = 0);
        return;
      }

      final DateTime now = DateTime.now();
      final DateTime? previous = _lastBackPressAt;
      if (previous == null ||
          now.difference(previous) > const Duration(seconds: 2)) {
        _lastBackPressAt = now;
        if (mounted) {
          IzyTelFeedback.show(
            context,
            'Appuie encore une fois pour quitter IzyTel.',
          );
        }
        return;
      }

      await SystemNavigator.pop();
    } finally {
      _handlingSystemBack = false;
    }
  }

  void _selectDestination(int index) {
    _disarmExit();
    _popTabToRoot(index);
    if (index == _selectedIndex) return;
    setState(() => _selectedIndex = index);
  }

  Widget _buildTabNavigator(int index, Widget rootPage) {
    return Navigator(
      key: _tabNavigatorKeys[index],
      observers: <NavigatorObserver>[_tabNavigatorObservers[index]],
      onGenerateRoute: (RouteSettings settings) {
        return MaterialPageRoute<void>(
          settings: settings,
          builder: (_) => rootPage,
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    if (widget.user.role == UserRole.agent) {
      return _AgentShell(
        user: widget.user,
        authRepository: widget.authRepository,
        ordersRepository: widget.ordersRepository,
        agentRepository: widget.agentRepository,
        commissionRepository: widget.commissionRepository,
      );
    }

    final List<Widget> pages = <Widget>[
      DashboardPage(
        user: widget.user,
        dashboardRepository: widget.dashboardRepository,
        orderHistoryRepository:
            widget.ordersRepository is OrderHistoryRepository
            ? widget.ordersRepository as OrderHistoryRepository
            : null,
        ordersRepository: widget.ordersRepository,
        agentRepository: widget.agentRepository,
        onOpenOrders: _openOrdersTab,
        onOpenPayments: _openPaymentsTab,
        onOpenMore: _openMoreTab,
        onLogout: _logoutAdmin,
      ),
      OrdersPage(
        user: widget.user,
        ordersRepository: widget.ordersRepository,
        agentRepository: widget.agentRepository,
      ),
      PaymentsPage(
        user: widget.user,
        ordersRepository: widget.ordersRepository,
        onPaymentConfirmed: _handlePaymentConfirmed,
        onOpenOrders: _openOrdersTab,
        onOpenOrder: (QueueOrder order) => unawaited(_openSpecificOrder(order)),
      ),
      widget.user.isManager
          ? AgentManagementPage(
              user: widget.user,
              repository: widget.agentRepository,
            )
          : FinancesPage(
              user: widget.user,
              ordersRepository: widget.ordersRepository,
              commissionRepository: widget.commissionRepository,
              agentRepository: widget.agentRepository,
              onOpenPayments: _openPaymentsTab,
            ),
      MorePage(
        user: widget.user,
        authRepository: widget.authRepository,
        adminOfferRepository: widget.adminOfferRepository,
        agentRepository: widget.agentRepository,
        ordersRepository: widget.ordersRepository,
        commissionRepository: widget.commissionRepository,
        onOpenPayments: _openPaymentsTab,
      ),
    ];

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (bool didPop, Object? result) {
        if (!didPop) unawaited(_handleSystemBack());
      },
      child: Scaffold(
        backgroundColor: IzyTelColors.background,
        body: IndexedStack(
          index: _selectedIndex,
          children: List<Widget>.generate(
            pages.length,
            (int index) => _buildTabNavigator(index, pages[index]),
          ),
        ),
        bottomNavigationBar: CabineBottomNavigationBar(
          selectedIndex: _selectedIndex,
          onDestinationSelected: _selectDestination,
          managerMode: widget.user.isManager,
        ),
      ),
    );
  }
}

class _AgentShell extends StatefulWidget {
  const _AgentShell({
    required this.user,
    required this.authRepository,
    required this.ordersRepository,
    required this.agentRepository,
    required this.commissionRepository,
  });

  final AppUser user;
  final AuthRepository authRepository;
  final OrdersRepository ordersRepository;
  final AgentRepository agentRepository;
  final CommissionRepository commissionRepository;

  @override
  State<_AgentShell> createState() => _AgentShellState();
}

class _AgentShellState extends State<_AgentShell> {
  int _selectedIndex = 0;
  bool _isLoggingOut = false;
  DateTime? _lastBackPressAt;
  bool _handlingSystemBack = false;
  late final List<NavigatorObserver> _tabNavigatorObservers;
  StreamSubscription<IzyTelNotificationPayload>? _notificationOpenedSubscription;
  StreamSubscription<IzyTelNotificationPayload>? _notificationForegroundSubscription;
  final ValueNotifier<IzyTelNotificationPayload?> _notificationOrderRequest =
      ValueNotifier<IzyTelNotificationPayload?>(null);
  final List<GlobalKey<NavigatorState>> _tabNavigatorKeys =
      List<GlobalKey<NavigatorState>>.generate(
        4,
        (int index) =>
            GlobalKey<NavigatorState>(debugLabel: 'agent-tab-$index'),
      );

  @override
  void initState() {
    super.initState();
    _tabNavigatorObservers = List<NavigatorObserver>.generate(
      _tabNavigatorKeys.length,
      (_) => _IzyTelTabNavigationObserver(_disarmExit),
    );
    _notificationForegroundSubscription =
        FirebaseMessagingBootstrap.foregroundPayloads.listen(
      (IzyTelNotificationPayload payload) {
        if (!mounted) return;
        IzyTelFeedback.show(context, payload.displayMessage);
      },
      onError: (Object error) {
        debugPrint('[FCM][agent-foreground-stream] $error');
      },
    );
    _notificationOpenedSubscription =
        FirebaseMessagingBootstrap.openedPayloads.listen(
      (IzyTelNotificationPayload payload) {
        _handleAgentNotificationOpen(payload);
      },
      onError: (Object error) {
        debugPrint('[FCM][agent-opened-stream] $error');
      },
    );
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      final IzyTelNotificationPayload? pending =
          FirebaseMessagingBootstrap.takePendingOpenedPayload();
      if (pending != null) _handleAgentNotificationOpen(pending);
    });
  }

  void _handleAgentNotificationOpen(IzyTelNotificationPayload payload) {
    if (!mounted) return;
    if (payload.targetsOrder ||
        payload.type == 'order_assigned' ||
        payload.type == 'order_reassigned') {
      _selectDestination(1);
      _popTabToRoot(1);
      _notificationOrderRequest.value = null;
      scheduleMicrotask(() {
        if (mounted) _notificationOrderRequest.value = payload;
      });
      return;
    }

    if (payload.type == 'agent_issue_resolved') {
      _selectDestination(3);
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        final NavigatorState? profileNavigator =
            _tabNavigatorKeys[3].currentState;
        profileNavigator?.popUntil((Route<dynamic> route) => route.isFirst);
        profileNavigator?.push<void>(
          MaterialPageRoute<void>(
            builder: (_) => AgentIssuesPage(
              agentId: widget.user.id,
              repository: widget.agentRepository,
            ),
          ),
        );
      });
    }
  }

  @override
  void dispose() {
    _notificationOpenedSubscription?.cancel();
    _notificationForegroundSubscription?.cancel();
    _notificationOrderRequest.dispose();
    super.dispose();
  }

  Future<void> _logout() async {
    if (_isLoggingOut) return;

    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) {
        return AlertDialog(
          title: const Text('Se déconnecter ?'),
          content: const Text(
            'Tu devras te reconnecter pour accéder de nouveau à ton espace Agent.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(dialogContext).pop(false),
              child: const Text('Annuler'),
            ),
            FilledButton.icon(
              onPressed: () => Navigator.of(dialogContext).pop(true),
              icon: const Icon(Symbols.logout_rounded),
              label: const Text('Se déconnecter'),
            ),
          ],
        );
      },
    );

    if (confirmed != true || !mounted) return;

    setState(() {
      _isLoggingOut = true;
    });

    try {
      await IzyTelNotificationDeviceRegistry.deactivateCurrentDevice();
      await widget.authRepository.logout();
      await SessionPreferences.clear();
      if (!mounted) return;
      Navigator.of(context, rootNavigator: true).pushNamedAndRemoveUntil(
        AppRoutes.login,
        (Route<dynamic> route) => false,
      );
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _isLoggingOut = false;
      });
      IzyTelFeedback.error(
        context,
        'Impossible de se déconnecter pour le moment.',
      );
    }
  }

  void _disarmExit() {
    _lastBackPressAt = null;
  }

  void _popTabToRoot(int index) {
    _tabNavigatorKeys[index].currentState?.popUntil(
      (Route<dynamic> route) => route.isFirst,
    );
  }

  Future<void> _handleSystemBack() async {
    if (_handlingSystemBack) return;
    _handlingSystemBack = true;
    try {
      final NavigatorState? currentNavigator =
          _tabNavigatorKeys[_selectedIndex].currentState;

      if (currentNavigator != null && await currentNavigator.maybePop()) {
        _disarmExit();
        return;
      }

      if (_selectedIndex != 0) {
        _disarmExit();
        _popTabToRoot(0);
        if (mounted) setState(() => _selectedIndex = 0);
        return;
      }

      final DateTime now = DateTime.now();
      final DateTime? previous = _lastBackPressAt;
      if (previous == null ||
          now.difference(previous) > const Duration(seconds: 2)) {
        _lastBackPressAt = now;
        if (mounted) {
          IzyTelFeedback.show(
            context,
            'Appuie encore une fois pour quitter IzyTel.',
          );
        }
        return;
      }

      await SystemNavigator.pop();
    } finally {
      _handlingSystemBack = false;
    }
  }

  void _selectDestination(int index) {
    _disarmExit();
    _popTabToRoot(index);
    if (index == _selectedIndex) return;
    setState(() => _selectedIndex = index);
  }

  Widget _buildTabNavigator(int index, Widget rootPage) {
    return Navigator(
      key: _tabNavigatorKeys[index],
      observers: <NavigatorObserver>[_tabNavigatorObservers[index]],
      onGenerateRoute: (RouteSettings settings) {
        return MaterialPageRoute<void>(
          settings: settings,
          builder: (_) => rootPage,
        );
      },
    );
  }

  void _openAgentOrders() {
    _selectDestination(1);
  }

  void _openAgentProfile() {
    _selectDestination(3);
    _popTabToRoot(3);
  }

  void _openAgentHistory() {
    _selectDestination(2);
  }

  void _openAgentPerformance() {
    final int navigatorIndex = _selectedIndex;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _tabNavigatorKeys[navigatorIndex].currentState?.push<void>(
        MaterialPageRoute<void>(
          builder: (_) => AgentActivityV2DashboardPage(
            agentId: widget.user.id,
            agentName: widget.user.name,
          ),
        ),
      );
    });
  }

  void _openAgentCommissions() {
    final int navigatorIndex = _selectedIndex;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      _tabNavigatorKeys[navigatorIndex].currentState?.push<void>(
        MaterialPageRoute<void>(
          builder: (_) => AgentCommissionsPage(
            user: widget.user,
            repository: widget.commissionRepository,
          ),
        ),
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    final List<Widget> pages = <Widget>[
      AgentHomePage(
        user: widget.user,
        ordersRepository: widget.ordersRepository,
        agentRepository: widget.agentRepository,
        onOpenOrders: _openAgentOrders,
        onOpenHistory: _openAgentHistory,
        onOpenProfile: _openAgentProfile,
        onOpenActivity: _openAgentPerformance,
        onOpenCommissions: _openAgentCommissions,
      ),
      AgentOrdersPage(
        user: widget.user,
        ordersRepository: widget.ordersRepository,
        agentRepository: widget.agentRepository,
        notificationOrderRequest: _notificationOrderRequest,
        onOpenProfile: _openAgentProfile,
        onOpenPerformance: _openAgentPerformance,
        onOpenCommissions: _openAgentCommissions,
        onLogout: _logout,
      ),
      AgentHistoryPage(
        user: widget.user,
        ordersRepository: widget.ordersRepository,
        agentRepository: widget.agentRepository,
      ),
      AgentActivityPage(
        user: widget.user,
        repository: widget.agentRepository,
        isLoggingOut: _isLoggingOut,
        onLogout: _logout,
        onOpenActivity: _openAgentPerformance,
        onOpenCommissions: _openAgentCommissions,
      ),
    ];

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (bool didPop, Object? result) {
        if (!didPop) unawaited(_handleSystemBack());
      },
      child: Scaffold(
        backgroundColor: IzyTelColors.background,
        body: IndexedStack(
          index: _selectedIndex,
          children: List<Widget>.generate(
            pages.length,
            (int index) => _buildTabNavigator(index, pages[index]),
          ),
        ),
        bottomNavigationBar: _AgentBottomNavigationBar(
          selectedIndex: _selectedIndex,
          onDestinationSelected: _selectDestination,
        ),
      ),
    );
  }
}

class _IzyTelTabNavigationObserver extends NavigatorObserver {
  _IzyTelTabNavigationObserver(this.onNavigation);

  final VoidCallback onNavigation;

  @override
  void didPush(Route<dynamic> route, Route<dynamic>? previousRoute) {
    onNavigation();
  }

  @override
  void didPop(Route<dynamic> route, Route<dynamic>? previousRoute) {
    onNavigation();
  }

  @override
  void didRemove(Route<dynamic> route, Route<dynamic>? previousRoute) {
    onNavigation();
  }

  @override
  void didReplace({Route<dynamic>? newRoute, Route<dynamic>? oldRoute}) {
    onNavigation();
  }

  @override
  void didStartUserGesture(Route<dynamic> route, Route<dynamic>? previousRoute) {
    onNavigation();
  }
}

class _AgentBottomNavigationBar extends StatelessWidget {
  const _AgentBottomNavigationBar({
    required this.selectedIndex,
    required this.onDestinationSelected,
  });

  final int selectedIndex;
  final ValueChanged<int> onDestinationSelected;

  @override
  Widget build(BuildContext context) {
    const List<_AgentNavigationItem> items = <_AgentNavigationItem>[
      _AgentNavigationItem(
        label: 'Accueil',
        icon: Symbols.home_rounded,
        selectedIcon: Symbols.home_rounded,
      ),
      _AgentNavigationItem(
        label: 'Commandes',
        icon: Symbols.receipt_long_rounded,
        selectedIcon: Symbols.receipt_long_rounded,
      ),
      _AgentNavigationItem(
        label: 'Historique',
        icon: Symbols.history_rounded,
        selectedIcon: Symbols.history_rounded,
      ),
      _AgentNavigationItem(
        label: 'Profil',
        icon: Symbols.person_rounded,
        selectedIcon: Symbols.person_rounded,
      ),
    ];

    return DecoratedBox(
      decoration: const BoxDecoration(
        color: IzyTelColors.surface,
        border: Border(top: BorderSide(color: IzyTelColors.outline)),
        boxShadow: [
          BoxShadow(
            color: IzyTelColors.shadow,
            blurRadius: 22,
            offset: Offset(0, -8),
          ),
        ],
      ),
      child: SafeArea(
        top: false,
        child: SizedBox(
          height: 64,
          child: Row(
            children: List<Widget>.generate(items.length, (int index) {
              final _AgentNavigationItem item = items[index];
              final bool selected = selectedIndex == index;
              final Color color = selected
                  ? IzyTelColors.primary
                  : IzyTelColors.textSecondary;
              return Expanded(
                child: InkWell(
                  key: ValueKey<String>(
                    'agent-nav-${item.label.toLowerCase()}',
                  ),
                  onTap: () => onDestinationSelected(index),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Container(
                        width: 34,
                        height: 28,
                        alignment: Alignment.center,
                        decoration: BoxDecoration(
                          color: selected
                              ? IzyTelColors.primarySoft
                              : Colors.transparent,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Icon(
                          selected ? item.selectedIcon : item.icon,
                          size: IzyTelIconSize.navigation,
                          fill: selected ? 1 : 0,
                          weight: selected ? 600 : 450,
                          color: color,
                        ),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        item.label,
                        style: Theme.of(context).textTheme.labelMedium
                            ?.copyWith(
                              color: color,
                              fontSize: IzyTelTypeScale.micro,
                              fontWeight: selected
                                  ? FontWeight.w700
                                  : FontWeight.w500,
                            ),
                      ),
                    ],
                  ),
                ),
              );
            }),
          ),
        ),
      ),
    );
  }
}

class _AgentNavigationItem {
  const _AgentNavigationItem({
    required this.label,
    required this.icon,
    required this.selectedIcon,
  });

  final String label;
  final IconData icon;
  final IconData selectedIcon;
}
