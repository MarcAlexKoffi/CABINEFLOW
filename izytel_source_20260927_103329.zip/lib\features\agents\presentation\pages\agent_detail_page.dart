import 'package:cabine_flow/core/theme/izytel_colors.dart';
import 'package:cabine_flow/features/agents/domain/models/agent_models.dart';
import 'package:cabine_flow/features/agents/domain/repositories/agent_repository.dart';
import 'package:cabine_flow/features/agents/presentation/view_models/agent_detail_view_model.dart';
import 'package:cabine_flow/features/agents/presentation/widgets/agent_directory_avatar.dart';
import 'package:cabine_flow/features/auth/domain/models/app_user.dart';
import 'package:cabine_flow/features/auth/domain/permissions/user_permissions.dart';
import 'package:cabine_flow/features/team/presentation/pages/team_member_detail_page.dart';
import 'package:cabine_flow/shared/widgets/izytel/izytel_feedback.dart';
import 'package:flutter/material.dart';
import 'package:material_symbols_icons/symbols.dart';
import 'package:cabine_flow/features/agents/presentation/pages/admin_agent_profile_activity_page.dart';

class AgentDetailPage extends StatefulWidget {
  const AgentDetailPage({
    super.key,
    required this.agent,
    required this.zones,
    required this.repository,
    required this.viewer,
    this.readOnly = false,
  });

  final AgentDirectoryEntry agent;
  final List<AgentZone> zones;
  final AgentRepository repository;
  final AppUser viewer;
  final bool readOnly;

  @override
  State<AgentDetailPage> createState() => _AgentDetailPageState();
}

class _AgentDetailPageState extends State<AgentDetailPage> {
  late final AgentDetailViewModel _viewModel;
  late final TextEditingController _nameController;
  late final TextEditingController _phoneController;
  late final TextEditingController _dailyLimitController;
  late final TextEditingController _maxTransactionsController;
  late final Map<AgentNetwork, TextEditingController> _capacityControllers;
  bool _savingManagerCapacities = false;

  @override
  void initState() {
    super.initState();
    _viewModel = AgentDetailViewModel(
      agent: widget.agent,
      repository: widget.repository,
      zones: widget.zones,
    );
    _nameController = TextEditingController(text: _viewModel.name);
    _phoneController = TextEditingController(text: _viewModel.phoneNumber);
    _dailyLimitController = TextEditingController(
      text: '${_viewModel.dailyTransactionLimit}',
    );
    _maxTransactionsController = TextEditingController(
      text: '${_viewModel.maxTransactionsPerDay}',
    );
    _capacityControllers = <AgentNetwork, TextEditingController>{
      AgentNetwork.orange: TextEditingController(
        text: '${_viewModel.orangeCapacity}',
      ),
      AgentNetwork.mtn: TextEditingController(
        text: '${_viewModel.mtnCapacity}',
      ),
      AgentNetwork.moov: TextEditingController(
        text: '${_viewModel.moovCapacity}',
      ),
    };
  }

  @override
  void dispose() {
    _viewModel.dispose();
    _nameController.dispose();
    _phoneController.dispose();
    _dailyLimitController.dispose();
    _maxTransactionsController.dispose();
    for (final controller in _capacityControllers.values) {
      controller.dispose();
    }
    super.dispose();
  }

  void _syncFormToViewModel() {
    _viewModel.setName(_nameController.text);
    _viewModel.setPhone(_phoneController.text);
    _viewModel.setLimits(
      amount: int.tryParse(_dailyLimitController.text.trim()) ?? -1,
      count: int.tryParse(_maxTransactionsController.text.trim()) ?? -1,
    );
    for (final network in AgentNetwork.values) {
      _viewModel.setCapacity(
        network,
        int.tryParse(_capacityControllers[network]!.text.trim()) ?? 0,
      );
    }
  }

  Future<void> _save() async {
    _syncFormToViewModel();
    final bool success = await _viewModel.save();
    if (!mounted) return;
    if (success) {
      IzyTelFeedback.success(context, 'Profil agent enregistré.');
      Navigator.of(context).pop();
    } else {
      IzyTelFeedback.error(
        context,
        _viewModel.errorMessage ?? 'Enregistrement impossible.',
      );
    }
  }

  Future<void> _toggleAgentActiveState() async {
    if (_viewModel.isSaving) return;
    final bool targetActive = !_viewModel.isActive;
    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (BuildContext dialogContext) => AlertDialog(
        title: Text(
          targetActive ? 'Réactiver cet agent ?' : 'Suspendre cet agent ?',
        ),
        content: Text(
          targetActive
              ? 'L’agent pourra de nouveau se connecter. Il restera indisponible jusqu’à ce qu’il réactive lui-même ses réseaux.'
              : 'L’agent sera immédiatement désactivé et ne recevra plus de nouvelles affectations.',
        ),
        actions: <Widget>[
          TextButton(
            onPressed: () => Navigator.of(dialogContext).pop(false),
            child: const Text('Annuler'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(dialogContext).pop(true),
            child: Text(targetActive ? 'Réactiver' : 'Suspendre'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;

    final bool previous = _viewModel.isActive;
    _syncFormToViewModel();
    _viewModel.setActive(targetActive);
    final bool success = await _viewModel.save();
    if (!mounted) return;
    if (!success) {
      _viewModel.setActive(previous);
      IzyTelFeedback.error(
        context,
        _viewModel.errorMessage ??
            'Impossible de modifier le statut de l’agent.',
      );
      return;
    }

    IzyTelFeedback.success(
      context,
      targetActive ? 'Agent réactivé.' : 'Agent suspendu.',
    );
  }

  Future<void> _createZone() async {
    final TextEditingController name = TextEditingController();
    final TextEditingController city = TextEditingController(text: 'Abidjan');
    final TextEditingController region = TextEditingController(text: 'Abidjan');
    final bool? confirmed = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        backgroundColor: IzyTelColors.surfaceMuted,
        surfaceTintColor: Colors.transparent,
        title: const Text(
          'Créer une zone',
          style: TextStyle(color: IzyTelColors.textPrimary),
        ),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: name,
                style: const TextStyle(
                  color: IzyTelColors.textPrimary,
                  fontWeight: FontWeight.w600,
                ),
                cursorColor: IzyTelColors.primary,
                decoration: _darkInputDecoration('Nom de la zone'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: city,
                style: const TextStyle(
                  color: IzyTelColors.textPrimary,
                  fontWeight: FontWeight.w600,
                ),
                cursorColor: IzyTelColors.primary,
                decoration: _darkInputDecoration('Ville'),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: region,
                style: const TextStyle(
                  color: IzyTelColors.textPrimary,
                  fontWeight: FontWeight.w600,
                ),
                cursorColor: IzyTelColors.primary,
                decoration: _darkInputDecoration('Région'),
              ),
            ],
          ),
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Annuler'),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text('Créer'),
          ),
        ],
      ),
    );
    if (confirmed != true || !mounted) return;
    if (name.text.trim().length < 2 ||
        city.text.trim().length < 2 ||
        region.text.trim().length < 2) {
      IzyTelFeedback.show(
        context,
        'Complète correctement les informations de la zone.',
        tone: IzyTelFeedbackTone.warning,
      );
      return;
    }
    final String? id = await _viewModel.createZone(
      name: name.text,
      city: city.text,
      region: region.text,
    );
    if (!mounted) return;
    final String message = id == null
        ? _viewModel.errorMessage ?? 'Création impossible.'
        : 'Zone créée. Rouvre la fiche pour l’assigner après synchronisation.';
    if (id == null) {
      IzyTelFeedback.error(context, message);
    } else {
      IzyTelFeedback.success(context, message);
    }
  }

  void _openDetailedProfile() {
    Navigator.of(context).push<void>(
      MaterialPageRoute<void>(
        builder: (_) => widget.viewer.isManager
            ? TeamMemberDetailPage(
                viewer: widget.viewer,
                actorType: 'agent',
                actorId: widget.agent.userId,
                fallbackName: widget.agent.name,
              )
            : AdminAgentProfileActivityPage(
                agentId: widget.agent.userId,
                agentName: widget.agent.name,
              ),
      ),
    );
  }

  bool get _canEditCapacities => !widget.readOnly || widget.viewer.isManager;

  Future<void> _saveManagerCapacities() async {
    if (!widget.viewer.isManager || _savingManagerCapacities) return;
    final AgentProfile? profile = widget.agent.profile;
    if (profile == null) {
      IzyTelFeedback.error(context, 'Profil opérationnel Agent indisponible.');
      return;
    }

    final Map<AgentNetwork, int> next = <AgentNetwork, int>{};
    for (final AgentNetwork network in AgentNetwork.values) {
      final int? value = int.tryParse(
        _capacityControllers[network]!.text.trim(),
      );
      if (value == null || value < 0 || value > 100000000) {
        IzyTelFeedback.show(
          context,
          'Vérifie la capacité ${network.label}.',
          tone: IzyTelFeedbackTone.warning,
        );
        return;
      }
      next[network] = value;
    }

    setState(() => _savingManagerCapacities = true);
    try {
      for (final AgentNetwork network in AgentNetwork.values) {
        final int value = next[network]!;
        if (value == profile.capacityFor(network)) continue;
        await widget.repository.adjustManagedAgentCapacity(
          agentId: widget.agent.userId,
          network: network,
          targetCapacity: value,
          reason: 'Ajustement capacité par Manager',
        );
      }
      if (!mounted) return;
      IzyTelFeedback.success(context, 'Capacités Agent enregistrées.');
      Navigator.of(context).pop();
    } catch (error) {
      if (!mounted) return;
      IzyTelFeedback.error(context, error.toString());
    } finally {
      if (mounted) setState(() => _savingManagerCapacities = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final AgentProfile? profile = widget.agent.profile;
    return Scaffold(
      backgroundColor: IzyTelColors.background,
      appBar: AppBar(
        title: Text(widget.readOnly ? 'Supervision Agent' : 'Profil Agent'),
      ),
      body: SafeArea(
        top: false,
        child: ListenableBuilder(
          listenable: _viewModel,
          builder: (_, _) {
            return ListView(
              padding: const EdgeInsets.fromLTRB(20, 16, 20, 32),
              children: [
                _ProfileHeader(
                  agent: widget.agent,
                  isActive: _viewModel.isActive,
                ),
                const SizedBox(height: 12),
                SizedBox(
                  width: double.infinity,
                  child: OutlinedButton.icon(
                    onPressed: _openDetailedProfile,
                    icon: const Icon(Symbols.manage_accounts_rounded),
                    label: const Text('Identité et activité détaillée'),
                  ),
                ),
                const SizedBox(height: 16),
                _SectionCard(
                  title: 'Identité',
                  icon: Symbols.person_rounded,
                  child: Column(
                    children: [
                      TextField(
                        controller: _nameController,
                        readOnly: widget.readOnly,
                        style: const TextStyle(
                          color: IzyTelColors.textPrimary,
                          fontWeight: FontWeight.w600,
                        ),
                        cursorColor: IzyTelColors.primary,
                        decoration: _darkInputDecoration('Nom complet'),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: _phoneController,
                        readOnly: widget.readOnly,
                        keyboardType: TextInputType.phone,
                        style: const TextStyle(
                          color: IzyTelColors.textPrimary,
                          fontWeight: FontWeight.w600,
                        ),
                        cursorColor: IzyTelColors.primary,
                        decoration: _darkInputDecoration('Téléphone'),
                      ),
                      const SizedBox(height: 10),
                      _ReadOnlyLine(
                        label: 'E-mail',
                        value: widget.agent.email.isEmpty
                            ? 'Non renseigné'
                            : widget.agent.email,
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                _SectionCard(
                  title: 'Zones assignées',
                  icon: Symbols.location_on_rounded,
                  trailing: widget.readOnly
                      ? null
                      : TextButton.icon(
                          onPressed: _createZone,
                          icon: const Icon(Symbols.add_rounded, size: 18),
                          label: const Text('Créer'),
                        ),
                  child: widget.zones.isEmpty
                      ? Text(
                          widget.readOnly
                              ? 'Aucune zone n’est assignée à cet agent.'
                              : 'Aucune zone n’existe encore. Crée la première zone puis assigne-la à l’agent.',
                          style: const TextStyle(
                            color: IzyTelColors.textSecondary,
                          ),
                        )
                      : Wrap(
                          spacing: 8,
                          runSpacing: 8,
                          children: widget.zones
                              .where((zone) => zone.isActive)
                              .map((zone) {
                                final bool selected = _viewModel.zoneIds
                                    .contains(zone.id);
                                return FilterChip(
                                  label: Text(zone.displayLabel),
                                  selected: selected,
                                  onSelected: widget.readOnly
                                      ? null
                                      : (_) => _viewModel.toggleZone(zone.id),
                                  selectedColor: IzyTelColors.primary.withAlpha(
                                    55,
                                  ),
                                  side: BorderSide(
                                    color: selected
                                        ? IzyTelColors.primary
                                        : IzyTelColors.outline,
                                  ),
                                );
                              })
                              .toList(growable: false),
                        ),
                ),
                const SizedBox(height: 16),
                _SectionCard(
                  title: 'Capacités & limites',
                  icon: Symbols.tune_rounded,
                  child: Column(
                    children: [
                      TextField(
                        controller: _dailyLimitController,
                        readOnly: widget.readOnly,
                        keyboardType: TextInputType.number,
                        style: const TextStyle(
                          color: IzyTelColors.textPrimary,
                          fontWeight: FontWeight.w600,
                        ),
                        cursorColor: IzyTelColors.primary,
                        decoration: _darkInputDecoration(
                          'Limite transactions / jour (FCFA)',
                        ),
                      ),
                      const SizedBox(height: 10),
                      TextField(
                        controller: _maxTransactionsController,
                        readOnly: widget.readOnly,
                        keyboardType: TextInputType.number,
                        style: const TextStyle(
                          color: IzyTelColors.textPrimary,
                          fontWeight: FontWeight.w600,
                        ),
                        cursorColor: IzyTelColors.primary,
                        decoration: _darkInputDecoration(
                          'Nombre max de transactions / jour',
                        ),
                      ),
                      const SizedBox(height: 14),
                      ...AgentNetwork.values.map(
                        (network) => Padding(
                          padding: const EdgeInsets.only(bottom: 10),
                          child: TextField(
                            controller: _capacityControllers[network],
                            readOnly: !_canEditCapacities,
                            keyboardType: TextInputType.number,
                            style: const TextStyle(
                              color: IzyTelColors.textPrimary,
                              fontWeight: FontWeight.w600,
                            ),
                            cursorColor: IzyTelColors.primary,
                            decoration: _darkInputDecoration(
                              'Capacité ${network.label} (FCFA)',
                              prefixIcon: Icon(
                                Symbols.account_balance_wallet_rounded,
                                color: _networkColor(network),
                              ),
                            ),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 16),
                _SectionCard(
                  title: 'Réseaux autorisés',
                  icon: Symbols.hub_rounded,
                  child: Column(
                    children: AgentNetwork.values
                        .map((network) {
                          final bool enabled = _viewModel.authorizedNetworks
                              .contains(network);
                          return Container(
                            margin: const EdgeInsets.only(bottom: 9),
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 8,
                            ),
                            decoration: BoxDecoration(
                              color: IzyTelColors.surfaceMuted,
                              borderRadius: BorderRadius.circular(12),
                              border: Border.all(color: IzyTelColors.outline),
                            ),
                            child: Row(
                              children: [
                                Container(
                                  width: 5,
                                  height: 36,
                                  decoration: BoxDecoration(
                                    color: _networkColor(network),
                                    borderRadius: BorderRadius.circular(999),
                                  ),
                                ),
                                const SizedBox(width: 10),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        network.label,
                                        style: const TextStyle(
                                          color: IzyTelColors.textPrimary,
                                          fontWeight: FontWeight.w700,
                                        ),
                                      ),
                                      Text(
                                        enabled ? 'Autorisé' : 'Non autorisé',
                                        style: const TextStyle(
                                          color: IzyTelColors.textSecondary,
                                          fontSize: 11,
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                                Switch(
                                  value: enabled,
                                  onChanged: widget.readOnly
                                      ? null
                                      : (_) => _viewModel.toggleNetwork(network),
                                ),
                              ],
                            ),
                          );
                        })
                        .toList(growable: false),
                  ),
                ),
                const SizedBox(height: 16),
                _SectionCard(
                  title: 'Activité récente',
                  icon: Symbols.history_rounded,
                  child: Column(
                    children: [
                      _ActivityLine(
                        color: IzyTelColors.primary,
                        title: 'Dernière activité',
                        value: profile?.lastSeenAt == null
                            ? 'Aucune donnée'
                            : _formatDate(profile!.lastSeenAt!),
                      ),
                      const SizedBox(height: 10),
                      _ActivityLine(
                        color: IzyTelColors.success,
                        title: 'Dernière déclaration de capacité',
                        value: profile?.lastCapacityUpdateAt == null
                            ? 'Aucune donnée'
                            : _formatDate(profile!.lastCapacityUpdateAt!),
                      ),
                    ],
                  ),
                ),
                if (!widget.readOnly) ...[
                  const SizedBox(height: 18),
                  FilledButton.icon(
                    onPressed: _viewModel.isSaving ? null : _save,
                    icon: _viewModel.isSaving
                        ? const SizedBox(
                            width: 18,
                            height: 18,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Symbols.save_rounded),
                    label: const Text('Enregistrer les modifications'),
                  ),
                  const SizedBox(height: 10),
                  OutlinedButton.icon(
                    onPressed: _viewModel.isSaving
                        ? null
                        : _toggleAgentActiveState,
                    icon: Icon(
                      _viewModel.isActive
                          ? Symbols.block_rounded
                          : Symbols.check_circle_rounded,
                    ),
                    label: Text(
                      _viewModel.isActive
                          ? 'Suspendre l’agent'
                          : 'Réactiver l’agent',
                    ),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: _viewModel.isActive
                          ? IzyTelColors.error
                          : IzyTelColors.success,
                    ),
                  ),
                ],
                if (widget.readOnly && widget.viewer.isManager) ...[
                  const SizedBox(height: 18),
                  FilledButton.icon(
                    onPressed: _savingManagerCapacities ? null : _saveManagerCapacities,
                    icon: const Icon(Symbols.account_balance_wallet_rounded),
                    label: const Text('Enregistrer les capacités Agent'),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    'Le Manager peut ajuster les capacités réseau de ses Agents, mais pas leur identité, leurs zones, leurs quotas ni leurs réseaux autorisés.',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      color: IzyTelColors.textSecondary,
                      fontSize: 12,
                    ),
                  ),
                ],
                if (_viewModel.errorMessage != null) ...[
                  const SizedBox(height: 10),
                  Text(
                    _viewModel.errorMessage!,
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: IzyTelColors.error),
                  ),
                ],
              ],
            );
          },
        ),
      ),
    );
  }
}

class _ProfileHeader extends StatelessWidget {
  const _ProfileHeader({required this.agent, required this.isActive});
  final AgentDirectoryEntry agent;
  final bool isActive;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(20),
    decoration: BoxDecoration(
      color: IzyTelColors.surface,
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: IzyTelColors.outline),
    ),
    child: Column(
      children: [
        Stack(
          clipBehavior: Clip.none,
          children: [
            AgentDirectoryAvatar(
              agentId: agent.userId,
              name: agent.name,
              size: 88,
            ),
            Positioned(
              right: 1,
              bottom: 2,
              child: Container(
                width: 15,
                height: 15,
                decoration: BoxDecoration(
                  color: isActive ? IzyTelColors.success : IzyTelColors.error,
                  shape: BoxShape.circle,
                  border: Border.all(color: IzyTelColors.surface, width: 2),
                ),
              ),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Text(
          agent.name,
          textAlign: TextAlign.center,
          style: const TextStyle(
            color: IzyTelColors.textPrimary,
            fontSize: 23,
            fontWeight: FontWeight.w900,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          agent.agentCode,
          style: const TextStyle(color: IzyTelColors.textSecondary),
        ),
        const SizedBox(height: 8),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          decoration: BoxDecoration(
            color: (isActive ? IzyTelColors.success : IzyTelColors.error)
                .withAlpha(28),
            borderRadius: BorderRadius.circular(999),
          ),
          child: Text(
            isActive ? 'Actif' : 'Suspendu',
            style: TextStyle(
              color: isActive ? IzyTelColors.success : IzyTelColors.error,
              fontSize: 11,
              fontWeight: FontWeight.w800,
            ),
          ),
        ),
      ],
    ),
  );
}

class _SectionCard extends StatelessWidget {
  const _SectionCard({
    required this.title,
    required this.icon,
    required this.child,
    this.trailing,
  });
  final String title;
  final IconData icon;
  final Widget child;
  final Widget? trailing;

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(16),
    decoration: BoxDecoration(
      color: IzyTelColors.surface,
      borderRadius: BorderRadius.circular(16),
      border: Border.all(color: IzyTelColors.outline),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Icon(icon, color: IzyTelColors.primary, size: 20),
            const SizedBox(width: 8),
            Expanded(
              child: Text(
                title,
                style: const TextStyle(
                  color: IzyTelColors.textPrimary,
                  fontSize: 17,
                  fontWeight: FontWeight.w800,
                ),
              ),
            ),
            ?trailing,
          ],
        ),
        const SizedBox(height: 14),
        child,
      ],
    ),
  );
}

class _ReadOnlyLine extends StatelessWidget {
  const _ReadOnlyLine({required this.label, required this.value});
  final String label;
  final String value;
  @override
  Widget build(BuildContext context) => Container(
    width: double.infinity,
    padding: const EdgeInsets.all(12),
    decoration: BoxDecoration(
      color: IzyTelColors.surfaceMuted,
      borderRadius: BorderRadius.circular(12),
      border: Border.all(color: IzyTelColors.outline),
    ),
    child: Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: const TextStyle(
            color: IzyTelColors.textSecondary,
            fontSize: 11,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(
            color: IzyTelColors.textPrimary,
            fontWeight: FontWeight.w700,
          ),
        ),
      ],
    ),
  );
}

class _ActivityLine extends StatelessWidget {
  const _ActivityLine({
    required this.color,
    required this.title,
    required this.value,
  });
  final Color color;
  final String title;
  final String value;
  @override
  Widget build(BuildContext context) => Row(
    crossAxisAlignment: CrossAxisAlignment.start,
    children: [
      Container(
        width: 7,
        height: 7,
        margin: const EdgeInsets.only(top: 6),
        decoration: BoxDecoration(color: color, shape: BoxShape.circle),
      ),
      const SizedBox(width: 9),
      Expanded(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: const TextStyle(
                color: IzyTelColors.textPrimary,
                fontWeight: FontWeight.w700,
              ),
            ),
            Text(
              value,
              style: const TextStyle(
                color: IzyTelColors.textSecondary,
                fontSize: 11,
              ),
            ),
          ],
        ),
      ),
    ],
  );
}

InputDecoration _darkInputDecoration(
  String label, {
  Widget? prefixIcon,
  String? hintText,
}) {
  return InputDecoration(
    labelText: label,
    hintText: hintText,
    prefixIcon: prefixIcon,
    filled: true,
    fillColor: IzyTelColors.surfaceMuted,
    labelStyle: const TextStyle(
      color: IzyTelColors.textSecondary,
      fontWeight: FontWeight.w600,
    ),
    floatingLabelStyle: const TextStyle(
      color: IzyTelColors.primary,
      fontWeight: FontWeight.w700,
    ),
    hintStyle: const TextStyle(color: IzyTelColors.textSecondary),
    enabledBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: const BorderSide(color: IzyTelColors.outline),
    ),
    focusedBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: const BorderSide(color: IzyTelColors.primary, width: 1.5),
    ),
    errorBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: const BorderSide(color: IzyTelColors.error),
    ),
    focusedErrorBorder: OutlineInputBorder(
      borderRadius: BorderRadius.circular(12),
      borderSide: const BorderSide(color: IzyTelColors.error, width: 1.5),
    ),
  );
}

String _formatDate(DateTime value) {
  String two(int number) => number.toString().padLeft(2, '0');
  return '${two(value.day)}/${two(value.month)}/${value.year} à ${two(value.hour)}:${two(value.minute)}';
}

Color _networkColor(AgentNetwork network) {
  switch (network) {
    case AgentNetwork.orange:
      return IzyTelColors.orange;
    case AgentNetwork.mtn:
      return IzyTelColors.mtnText;
    case AgentNetwork.moov:
      return IzyTelColors.primary;
  }
}
