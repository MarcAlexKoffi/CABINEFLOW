enum CustomerBeneficiaryTarget { self, other }
