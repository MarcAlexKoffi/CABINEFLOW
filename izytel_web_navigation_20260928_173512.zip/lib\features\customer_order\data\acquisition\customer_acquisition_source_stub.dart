String? resolveCustomerAcquisitionSourceCode() => null;
