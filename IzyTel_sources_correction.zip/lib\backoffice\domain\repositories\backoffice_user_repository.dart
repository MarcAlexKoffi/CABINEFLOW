import 'package:cabine_flow/backoffice/domain/models/backoffice_user_account.dart';

enum BackofficeUserRegistrySource { firestore, supabase }

class BackofficeUserRegistryException implements Exception {
  const BackofficeUserRegistryException({
    required this.source,
    this.partial = false,
  });

  final BackofficeUserRegistrySource source;
  final bool partial;
}

abstract class BackofficeUserRepository {
  Stream<List<BackofficeUserAccount>> watchUsers();
}
