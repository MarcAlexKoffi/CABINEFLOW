import 'dart:typed_data';

import 'package:cabine_flow/features/agents/data/repositories/supabase_agent_personal_profile_repository.dart';
import 'package:cabine_flow/features/agents/domain/models/agent_personal_media.dart';
import 'package:cabine_flow/features/agents/domain/repositories/agent_repository.dart';
import 'package:cabine_flow/features/auth/domain/models/app_user.dart';
import 'package:cabine_flow/shared/widgets/izytel/izytel_feedback.dart';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';

class AgentPersonalProfilePage extends StatefulWidget {
  const AgentPersonalProfilePage({
    super.key,
    required this.user,
    this.repository,
    this.personalProfileRepository,
    this.roleLabel = 'Agent',
  });

  final AppUser user;
  final AgentRepository? repository;
  final SupabaseAgentPersonalProfileRepository? personalProfileRepository;
  final String roleLabel;

  @override
  State<AgentPersonalProfilePage> createState() =>
      _AgentPersonalProfilePageState();
}

class _AgentPersonalProfilePageState extends State<AgentPersonalProfilePage> {
  final _formKey = GlobalKey<FormState>();
  final ScrollController _scrollController = ScrollController();
  final GlobalKey<FormFieldState<String>> _firstNameKey =
      GlobalKey<FormFieldState<String>>();
  final GlobalKey<FormFieldState<String>> _lastNameKey =
      GlobalKey<FormFieldState<String>>();
  final GlobalKey _birthDateKey = GlobalKey();
  final GlobalKey<FormFieldState<String>> _addressKey =
      GlobalKey<FormFieldState<String>>();
  final GlobalKey<FormFieldState<String>> _cityKey =
      GlobalKey<FormFieldState<String>>();
  final GlobalKey<FormFieldState<String>> _contact1Key =
      GlobalKey<FormFieldState<String>>();
  final _picker = ImagePicker();
  SupabaseAgentPersonalProfileRepository? _profileRepository;

  final _firstName = TextEditingController();
  final _lastName = TextEditingController();
  final _address = TextEditingController();
  final _city = TextEditingController();
  final _contact1 = TextEditingController();
  final _contact2 = TextEditingController();
  final _emergencyName = TextEditingController();
  final _emergencyPhone = TextEditingController();
  final _identityNumber = TextEditingController();

  DateTime? _dateOfBirth;
  String _identityType = 'nationalId';
  String _verificationStatus = 'incomplete';
  String? _verificationNote;
  Map<String, dynamic>? _existingProfile;
  AgentPersonalMedia? _avatarMedia;
  AgentPersonalMedia? _identityMedia;
  PreparedAgentMedia? _pendingAvatar;
  PreparedAgentMedia? _pendingIdentity;
  bool _isLoading = true;
  bool _isSaving = false;
  bool _showValidationErrors = false;
  String? _error;
  String? _mediaWarning;

  bool get _isVerified => _verificationStatus == 'verified';

  @override
  void initState() {
    super.initState();
    _profileRepository = widget.personalProfileRepository;
    if (_profileRepository == null) {
      try {
        _profileRepository = SupabaseAgentPersonalProfileRepository();
      } catch (_) {
        // Les widget tests n'initialisent pas Supabase. Dans ce cas la page
        // reste rendable et affiche les informations déjà connues du compte.
      }
    }
    _load();
  }

  @override
  void dispose() {
    _firstName.dispose();
    _lastName.dispose();
    _address.dispose();
    _city.dispose();
    _contact1.dispose();
    _contact2.dispose();
    _emergencyName.dispose();
    _emergencyPhone.dispose();
    _identityNumber.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    if (mounted) {
      setState(() {
        _isLoading = true;
        _error = null;
        _mediaWarning = null;
      });
    }

    // Le compte Firebase reste l'identité de connexion pendant la migration.
    // Les données personnelles sont désormais lues exclusivement dans Supabase.
    _hydrateFromSignedInUser();

    final SupabaseAgentPersonalProfileRepository? repository =
        _profileRepository;
    if (repository == null) {
      _error =
          'Supabase n’est pas initialisé. Le profil reste consultable, mais ne peut pas encore être enregistré.';
      if (mounted) setState(() => _isLoading = false);
      return;
    }

    Map<String, dynamic>? data;
    try {
      data = await repository.fetchProfile(widget.user.id);
      if (data != null) {
        _existingProfile = Map<String, dynamic>.from(data);
        _firstName.text = _text(data['firstName']);
        _lastName.text = _text(data['lastName']);
        _address.text = _text(data['address']);
        _city.text = _text(data['city']);
        _contact1.text = _text(data['contact1']);
        _contact2.text = _text(data['contact2']);
        _emergencyName.text = _text(data['emergencyContactName']);
        _emergencyPhone.text = _text(data['emergencyContactPhone']);
        _identityNumber.text = _text(data['identityDocumentNumber']);
        _dateOfBirth = _date(data['dateOfBirth']);
        _identityType = _text(data['identityDocumentType']).isEmpty
            ? 'nationalId'
            : _text(data['identityDocumentType']);
        _verificationStatus = _text(data['verificationStatus']).isEmpty
            ? 'incomplete'
            : _text(data['verificationStatus']);
        _verificationNote = _nullableText(data['verificationNote']);
      } else {
        _existingProfile = null;
      }
    } catch (error) {
      _error =
          'Impossible de charger le profil Supabase pour le moment : $error';
    }

    final List<String> unavailableMedia = <String>[];
    if (data != null) {
      try {
        _avatarMedia = await repository.fetchMedia(
          agentId: widget.user.id,
          kind: AgentPersonalMediaKind.avatar,
          profile: data,
        );
      } catch (_) {
        _avatarMedia = null;
        unavailableMedia.add('photo de profil');
      }

      try {
        _identityMedia = await repository.fetchMedia(
          agentId: widget.user.id,
          kind: AgentPersonalMediaKind.identity,
          profile: data,
        );
      } catch (_) {
        _identityMedia = null;
        unavailableMedia.add('pièce d’identité');
      }
    } else {
      _avatarMedia = null;
      _identityMedia = null;
    }

    _pendingAvatar = null;
    _pendingIdentity = null;
    if (unavailableMedia.isNotEmpty) {
      _mediaWarning =
          'Certains médias Supabase sont temporairement indisponibles '
          '(${unavailableMedia.join(', ')}). Le formulaire reste utilisable.';
    }

    if (mounted) {
      setState(() => _isLoading = false);
    }
  }

  void _hydrateFromSignedInUser() {
    if (_firstName.text.isNotEmpty || _lastName.text.isNotEmpty) return;
    final List<String> parts = widget.user.name
        .trim()
        .split(RegExp(r'\s+'))
        .where((part) => part.isNotEmpty)
        .toList(growable: false);
    if (parts.isNotEmpty) {
      _firstName.text = parts.first;
      _lastName.text = parts.length > 1
          ? parts.skip(1).join(' ')
          : widget.roleLabel;
    }
    _contact1.text = widget.user.phoneNumber.trim();
  }

  Future<void> _pickAvatar() async {
    final ImageSource? source = await _chooseImageSource(
      title: 'Photo de profil',
    );
    if (source == null) return;
    try {
      final XFile? file = await _picker.pickImage(
        source: source,
        imageQuality: 95,
      );
      if (file == null) return;
      final Uint8List bytes = await file.readAsBytes();
      final SupabaseAgentPersonalProfileRepository? repository =
          _profileRepository;
      if (repository == null) {
        throw StateError(
          'Supabase doit être initialisé pour enregistrer la photo.',
        );
      }
      final String currentDisplayName = <String>[
        _firstName.text.trim(),
        _lastName.text.trim(),
      ].where((String value) => value.isNotEmpty).join(' ');
      await repository.saveAvatarOnly(
        agentId: widget.user.id,
        source: bytes,
        fallbackDisplayName: currentDisplayName.isEmpty
            ? widget.user.name
            : currentDisplayName,
      );
      if (!mounted) return;
      _pendingAvatar = null;
      IzyTelFeedback.success(context, 'Photo de profil mise à jour.');
      await _load();
    } catch (error) {
      _showError('$error');
    }
  }

  Future<void> _pickIdentityImage() async {
    if (_isVerified) {
      _showError('La pièce d’identité est verrouillée après vérification.');
      return;
    }
    final ImageSource? source = await _chooseImageSource(
      title: 'Pièce d’identité',
    );
    if (source == null) return;
    try {
      final XFile? file = await _picker.pickImage(
        source: source,
        imageQuality: 95,
      );
      if (file == null) return;
      final Uint8List bytes = await file.readAsBytes();
      final repository = _profileRepository;
      if (repository == null) {
        throw StateError(
          'Supabase doit être initialisé pour enregistrer la pièce.',
        );
      }
      final prepared = repository.prepareIdentityImage(
        source: bytes,
        fileName: file.name,
      );
      if (!mounted) return;
      setState(() => _pendingIdentity = prepared);
    } catch (error) {
      _showError('$error');
    }
  }

  Future<void> _pickIdentityPdf() async {
    if (_isVerified) {
      _showError('La pièce d’identité est verrouillée après vérification.');
      return;
    }
    try {
      final PlatformFile? file = await FilePicker.pickFile(
        dialogTitle: 'Sélectionner la pièce d’identité PDF',
        type: FileType.custom,
        allowedExtensions: const <String>['pdf'],
      );
      if (file == null) return;
      final int length = await file.length();
      if (length > SupabaseAgentPersonalProfileRepository.identityMaxBytes) {
        throw StateError('Le PDF doit faire moins de 850 Ko.');
      }
      final Uint8List bytes = await file.readAsBytes();
      final repository = _profileRepository;
      if (repository == null) {
        throw StateError(
          'Supabase doit être initialisé pour enregistrer la pièce.',
        );
      }
      final prepared = repository.prepareIdentityPdf(
        source: bytes,
        fileName: file.name,
      );
      if (!mounted) return;
      setState(() => _pendingIdentity = prepared);
    } catch (error) {
      _showError('$error');
    }
  }

  Future<ImageSource?> _chooseImageSource({required String title}) {
    return showModalBottomSheet<ImageSource>(
      context: context,
      builder: (context) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            ListTile(
              title: Text(
                title,
                style: const TextStyle(fontWeight: FontWeight.w800),
              ),
            ),
            ListTile(
              leading: const Icon(Icons.photo_camera_outlined),
              title: const Text('Prendre une photo'),
              onTap: () => Navigator.pop(context, ImageSource.camera),
            ),
            ListTile(
              leading: const Icon(Icons.photo_library_outlined),
              title: const Text('Choisir dans la galerie'),
              onTap: () => Navigator.pop(context, ImageSource.gallery),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _pickBirthDate() async {
    final DateTime now = DateTime.now();
    final DateTime firstDate = DateTime(1940);
    final DateTime lastDate = DateTime(now.year - 16, now.month, now.day);
    final DateTime candidate = _dateOfBirth ?? DateTime(now.year - 25, 1, 1);
    final DateTime initial = candidate.isBefore(firstDate)
        ? firstDate
        : candidate.isAfter(lastDate)
        ? lastDate
        : candidate;
    final DateTime? result = await showDatePicker(
      context: context,
      initialDate: initial,
      firstDate: firstDate,
      lastDate: lastDate,
    );
    if (result != null && mounted) {
      setState(() => _dateOfBirth = result);
    }
  }

  Future<void> _save() async {
    if (_isSaving) return;
    FocusManager.instance.primaryFocus?.unfocus();
    final bool formValid = _formKey.currentState?.validate() ?? false;
    final bool birthDateValid = _dateOfBirth != null;
    if (!formValid || !birthDateValid) {
      if (mounted) {
        setState(() => _showValidationErrors = true);
      }
      await _focusFirstInvalidField();
      if (mounted) {
        IzyTelFeedback.show(
          context,
          'Complète les champs obligatoires (*) indiqués en rouge.',
          tone: IzyTelFeedbackTone.warning,
        );
      }
      return;
    }
    setState(() {
      _isSaving = true;
      _showValidationErrors = false;
      _error = null;
    });
    try {
      final String firstName = _firstName.text.trim();
      final String lastName = _lastName.text.trim();
      final bool avatarPresent =
          _pendingAvatar != null ||
          _avatarMedia != null ||
          _existingProfile?['hasAvatarMedia'] == true ||
          _nullableText(_existingProfile?['avatarStoragePath']) != null;
      final bool identityPresent =
          _pendingIdentity != null ||
          _identityMedia != null ||
          _existingProfile?['hasIdentityDocumentMedia'] == true ||
          _nullableText(_existingProfile?['identityDocumentStoragePath']) !=
              null;
      final String nextVerification = _isVerified
          ? 'verified'
          : avatarPresent && identityPresent
          ? 'pendingReview'
          : 'incomplete';

      final SupabaseAgentPersonalProfileRepository? repository =
          _profileRepository;
      if (repository == null) {
        _verificationStatus = nextVerification;
        if (mounted) {
          IzyTelFeedback.show(
            context,
            'Supabase n’est pas initialisé : aucune écriture effectuée.',
            tone: IzyTelFeedbackTone.warning,
          );
        }
        return;
      }

      await repository.saveProfile(
        agentId: widget.user.id,
        firstName: firstName,
        lastName: lastName,
        dateOfBirth: _dateOfBirth!,
        address: _address.text.trim(),
        city: _city.text.trim(),
        contact1: _contact1.text.trim(),
        contact2: _contact2.text.trim(),
        emergencyContactName: _emergencyName.text.trim(),
        emergencyContactPhone: _emergencyPhone.text.trim(),
        identityDocumentType: _identityType,
        identityDocumentNumber: _identityNumber.text.trim(),
        verificationStatus: nextVerification,
        verificationNote: _isVerified ? _verificationNote : null,
        avatar: _pendingAvatar,
        identityDocument: _pendingIdentity,
      );

      if (!mounted) return;
      IzyTelFeedback.success(context, 'Profil enregistré sur Supabase.');
      await _load();
    } catch (error) {
      _showError('Supabase refuse l’enregistrement : $error');
    } finally {
      if (mounted) setState(() => _isSaving = false);
    }
  }

  Future<void> _focusFirstInvalidField() async {
    await Future<void>.delayed(Duration.zero);
    BuildContext? target;
    if (_firstNameKey.currentState?.hasError == true) {
      target = _firstNameKey.currentContext;
    } else if (_lastNameKey.currentState?.hasError == true) {
      target = _lastNameKey.currentContext;
    } else if (_dateOfBirth == null) {
      target = _birthDateKey.currentContext;
    } else if (_addressKey.currentState?.hasError == true) {
      target = _addressKey.currentContext;
    } else if (_cityKey.currentState?.hasError == true) {
      target = _cityKey.currentContext;
    } else if (_contact1Key.currentState?.hasError == true) {
      target = _contact1Key.currentContext;
    }
    if (target == null || !target.mounted) return;
    await Scrollable.ensureVisible(
      target,
      duration: const Duration(milliseconds: 320),
      curve: Curves.easeOutCubic,
      alignment: .18,
    );
  }

  void _showError(String message) {
    if (!mounted) return;
    setState(() => _error = message);
    IzyTelFeedback.error(context, message);
  }

  @override
  Widget build(BuildContext context) {
    if (_isLoading) {
      return const Scaffold(body: Center(child: CircularProgressIndicator()));
    }
    return Scaffold(
      appBar: AppBar(title: const Text('Informations personnelles')),
      body: Form(
        key: _formKey,
        child: ListView(
          controller: _scrollController,
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 28),
          children: <Widget>[
            _ProfileMediaHeader(
              bytes: _pendingAvatar?.bytes ?? _avatarMedia?.bytes,
              status: _verificationStatus,
              onPick: _pickAvatar,
            ),
            const SizedBox(height: 10),
            const _InfoCard(
              icon: Icons.info_outline,
              text: 'Les champs marqués * sont obligatoires.',
            ),
            if (_error != null) ...<Widget>[
              const SizedBox(height: 12),
              _InfoCard(icon: Icons.error_outline, text: _error!),
            ],
            if (_mediaWarning != null) ...<Widget>[
              const SizedBox(height: 12),
              _InfoCard(
                icon: Icons.image_not_supported_outlined,
                text: _mediaWarning!,
              ),
            ],
            if (_verificationNote != null) ...<Widget>[
              const SizedBox(height: 12),
              _InfoCard(
                icon: Icons.info_outline,
                text: 'Note de vérification : $_verificationNote',
              ),
            ],
            const SizedBox(height: 18),
            _sectionTitle(context, 'Identité'),
            const SizedBox(height: 8),
            _twoFields(
              _field(
                _firstName,
                'Prénom(s)',
                fieldKey: _firstNameKey,
                locked: _isVerified,
                minLength: 2,
                maxLength: 80,
              ),
              _field(
                _lastName,
                'Nom',
                fieldKey: _lastNameKey,
                locked: _isVerified,
                minLength: 2,
                maxLength: 80,
              ),
            ),
            const SizedBox(height: 10),
            InkWell(
              key: _birthDateKey,
              onTap: _isVerified ? null : _pickBirthDate,
              borderRadius: BorderRadius.circular(12),
              child: InputDecorator(
                decoration: InputDecoration(
                  labelText: 'Date de naissance *',
                  border: const OutlineInputBorder(),
                  suffixIcon: const Icon(Icons.calendar_month_outlined),
                  errorText: _showValidationErrors && _dateOfBirth == null
                      ? 'Champ obligatoire.'
                      : null,
                ),
                child: Text(_dateLabel(_dateOfBirth)),
              ),
            ),
            const SizedBox(height: 10),
            _field(
              _address,
              'Adresse / quartier',
              fieldKey: _addressKey,
              minLength: 3,
              maxLength: 200,
            ),
            const SizedBox(height: 10),
            _field(
              _city,
              'Ville / commune',
              fieldKey: _cityKey,
              minLength: 2,
              maxLength: 100,
            ),
            const SizedBox(height: 18),
            _sectionTitle(context, 'Contacts'),
            const SizedBox(height: 8),
            _field(
              _contact1,
              'Contact principal',
              fieldKey: _contact1Key,
              minLength: 8,
              maxLength: 30,
              keyboard: TextInputType.phone,
            ),
            const SizedBox(height: 10),
            _field(
              _contact2,
              'Contact secondaire (facultatif)',
              required: false,
              maxLength: 30,
              keyboard: TextInputType.phone,
            ),
            const SizedBox(height: 10),
            _twoFields(
              _field(
                _emergencyName,
                'Contact d’urgence — nom',
                required: false,
                maxLength: 100,
              ),
              _field(
                _emergencyPhone,
                'Téléphone urgence',
                required: false,
                maxLength: 30,
                keyboard: TextInputType.phone,
              ),
            ),
            const SizedBox(height: 18),
            _sectionTitle(context, 'Pièce d’identité'),
            const SizedBox(height: 8),
            DropdownButtonFormField<String>(
              initialValue: _identityType,
              decoration: const InputDecoration(
                labelText: 'Type de pièce',
                border: OutlineInputBorder(),
              ),
              items: const <DropdownMenuItem<String>>[
                DropdownMenuItem(value: 'nationalId', child: Text('CNI')),
                DropdownMenuItem(value: 'passport', child: Text('Passeport')),
                DropdownMenuItem(
                  value: 'drivingLicense',
                  child: Text('Permis de conduire'),
                ),
                DropdownMenuItem(
                  value: 'residencePermit',
                  child: Text('Titre de séjour'),
                ),
                DropdownMenuItem(value: 'other', child: Text('Autre')),
              ],
              onChanged: _isVerified
                  ? null
                  : (value) {
                      if (value != null) setState(() => _identityType = value);
                    },
            ),
            const SizedBox(height: 10),
            _field(
              _identityNumber,
              'Numéro de pièce (facultatif)',
              required: false,
              locked: _isVerified,
              maxLength: 80,
            ),
            const SizedBox(height: 12),
            _IdentityMediaCard(
              media: _pendingIdentity,
              current: _identityMedia,
              locked: _isVerified,
              onPickImage: _pickIdentityImage,
              onPickPdf: _pickIdentityPdf,
            ),
            const SizedBox(height: 8),
            Text(
              '850 Ko maximum. Les images sont compressées automatiquement. '
              'Les PDF trop lourds sont refusés. Les fichiers sont enregistrés dans ton espace privé Supabase IzyTel.',
              style: Theme.of(context).textTheme.bodySmall,
            ),
            const SizedBox(height: 20),
            FilledButton.icon(
              onPressed: _isSaving ? null : _save,
              icon: _isSaving
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.save_outlined),
              label: Text(_isSaving ? 'Enregistrement…' : 'Enregistrer'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _field(
    TextEditingController controller,
    String label, {
    GlobalKey<FormFieldState<String>>? fieldKey,
    bool required = true,
    bool locked = false,
    int minLength = 2,
    int? maxLength,
    TextInputType? keyboard,
  }) {
    return TextFormField(
      key: fieldKey,
      controller: controller,
      readOnly: locked,
      keyboardType: keyboard,
      autovalidateMode: _showValidationErrors
          ? AutovalidateMode.onUserInteraction
          : AutovalidateMode.disabled,
      decoration: InputDecoration(
        labelText: required ? '$label *' : label,
        border: const OutlineInputBorder(),
        filled: locked,
      ),
      validator: (value) {
        final String text = value?.trim() ?? '';
        if (required && text.length < minLength) {
          return text.isEmpty
              ? 'Champ obligatoire.'
              : 'Minimum $minLength caractères.';
        }
        if (!required && text.isNotEmpty && text.length < minLength) {
          return 'Minimum $minLength caractères.';
        }
        if (maxLength != null && text.length > maxLength) {
          return 'Maximum $maxLength caractères.';
        }
        return null;
      },
    );
  }

  Widget _twoFields(Widget first, Widget second) {
    return LayoutBuilder(
      builder: (context, constraints) {
        if (constraints.maxWidth < 560) {
          return Column(
            children: <Widget>[first, const SizedBox(height: 10), second],
          );
        }
        return Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Expanded(child: first),
            const SizedBox(width: 10),
            Expanded(child: second),
          ],
        );
      },
    );
  }
}

class _ProfileMediaHeader extends StatelessWidget {
  const _ProfileMediaHeader({
    required this.bytes,
    required this.status,
    required this.onPick,
  });

  final Uint8List? bytes;
  final String status;
  final VoidCallback onPick;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: <Widget>[
            CircleAvatar(
              radius: 38,
              foregroundImage: bytes == null ? null : MemoryImage(bytes!),
              child: bytes == null
                  ? const Icon(Icons.person_outline, size: 34)
                  : null,
            ),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  Text(
                    'Photo de profil',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(_verificationLabel(status)),
                  const SizedBox(height: 8),
                  TextButton.icon(
                    onPressed: onPick,
                    icon: const Icon(Icons.photo_camera_outlined),
                    label: const Text('Changer la photo'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _IdentityMediaCard extends StatelessWidget {
  const _IdentityMediaCard({
    required this.media,
    required this.current,
    required this.locked,
    required this.onPickImage,
    required this.onPickPdf,
  });

  final PreparedAgentMedia? media;
  final AgentPersonalMedia? current;
  final bool locked;
  final VoidCallback onPickImage;
  final VoidCallback onPickPdf;

  @override
  Widget build(BuildContext context) {
    final Uint8List? bytes = media?.bytes ?? current?.bytes;
    final String? mime = media?.mimeType ?? current?.mimeType;
    final String name = media?.fileName ?? current?.fileName ?? 'Aucun fichier';
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            if (bytes != null && mime == 'image/jpeg')
              ClipRRect(
                borderRadius: BorderRadius.circular(10),
                child: Image.memory(bytes, height: 180, fit: BoxFit.contain),
              )
            else
              const SizedBox(
                height: 90,
                child: Center(
                  child: Icon(Icons.picture_as_pdf_outlined, size: 42),
                ),
              ),
            const SizedBox(height: 8),
            Text(
              name,
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 10),
            Wrap(
              alignment: WrapAlignment.center,
              spacing: 8,
              runSpacing: 8,
              children: <Widget>[
                OutlinedButton.icon(
                  onPressed: locked ? null : onPickImage,
                  icon: const Icon(Icons.image_outlined),
                  label: const Text('Image'),
                ),
                OutlinedButton.icon(
                  onPressed: locked ? null : onPickPdf,
                  icon: const Icon(Icons.picture_as_pdf_outlined),
                  label: const Text('PDF'),
                ),
              ],
            ),
            if (locked) ...<Widget>[
              const SizedBox(height: 8),
              Text(
                'Pièce verrouillée : profil déjà vérifié.',
                textAlign: TextAlign.center,
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class _InfoCard extends StatelessWidget {
  const _InfoCard({required this.icon, required this.text});

  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.zero,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Icon(icon, size: 20),
            const SizedBox(width: 8),
            Expanded(child: Text(text)),
          ],
        ),
      ),
    );
  }
}

Widget _sectionTitle(BuildContext context, String text) {
  return Text(
    text,
    style: Theme.of(
      context,
    ).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w800),
  );
}

String _verificationLabel(String value) => switch (value) {
  'verified' => 'Profil vérifié',
  'pendingReview' => 'En attente de vérification',
  'needsCorrection' => 'Corrections demandées',
  _ => 'Profil incomplet',
};

String _dateLabel(DateTime? date) {
  if (date == null) return 'Sélectionner une date';
  String two(int value) => value.toString().padLeft(2, '0');
  return '${two(date.day)}/${two(date.month)}/${date.year}';
}

String _text(Object? value) => value is String ? value.trim() : '';
String? _nullableText(Object? value) {
  final text = _text(value);
  return text.isEmpty ? null : text;
}

DateTime? _date(Object? value) {
  if (value is DateTime) return value;
  if (value is String && value.trim().isNotEmpty) {
    return DateTime.tryParse(value.trim());
  }
  return null;
}
